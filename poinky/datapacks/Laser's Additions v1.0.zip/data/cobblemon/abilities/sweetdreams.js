{
  onResidualOrder: 28,
  onResidualSubOrder: 2,
  onResidual(pokemon) {
    if (!pokemon.hp) {
      return;
    }
    if (pokemon.status === "slp") {
        this.heal(pokemon.baseMaxhp / 8);
    }
      for (const target of pokemon.allies()) {
      if (target.status === "slp" || target.hasAbility("comatose")) {
        this.heal(target.baseMaxhp / 8, target, pokemon);
      }
    }
  },
  flags: {},
  name: "Sweet Dreams",
    rating: 3.5,
    num: -3222
}