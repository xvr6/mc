{
  onUpdate(pokemon) {
    if (pokemon.status === "brn") {
      this.add("-activate", pokemon, "ability: Hot Sand");
      pokemon.cureStatus();
    }
  },
  onImmunity(type, pokemon) {
    if (type === "brn") {
      return false;
    }
  },
  onDamagingHit(damage, target, source, move) {
    if (this.checkMoveMakesContact(move, source, target)) {
      if (this.randomChance(3, 10)) {
        source.trySetStatus("brn", target);
      }
    }
  },
  flags: {},
  name: "Hot Sand",
    rating: 3.5,
    num: -3213
}