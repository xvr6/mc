{
    onEatItem(item, pokemon) {
      pokemon.addVolatile("stockpile");
    },
    flags: {},
    name: "Gourmand",
    rating: 3.5,
    num: -3256
}