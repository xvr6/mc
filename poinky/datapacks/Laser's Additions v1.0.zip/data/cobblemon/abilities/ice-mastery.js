{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Ice"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Ice") {
        if (!this.boost({ spa: 1 })) {
          this.add("-immune", target, "[from] ability: Ice Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Ice") {
        this.boost({ spa: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Ice Mastery",
    rating: 3.5,
    num: -3214
  }