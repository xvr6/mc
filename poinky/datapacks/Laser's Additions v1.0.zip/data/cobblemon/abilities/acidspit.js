{
    onDamagingHit(damage, target, source, move) {
      if (this.checkMoveMakesContact(move, source, target)) {
        this.add("-activate", target, "ability: Acid Spit");
        source.addVolatile("gastroacid", this.effectState.target);
      }
    },
    flags: {},
    name: "Acid Spit",
    rating: 3.5,
    num: -3262
}