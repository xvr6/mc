{
    onTryHit(target, source, move) {
      if (target !== source && move.flags["light"]) {
        this.add("-immune", target, "[from] ability: Blindfold");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Blindfold",
    rating: 3.5,
    num: -3237
}