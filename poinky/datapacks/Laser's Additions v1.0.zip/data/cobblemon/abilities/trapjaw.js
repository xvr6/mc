{
    onSourceDamagingHit(damage, target, source, move) {
      if (move.flags["bite"]) {
        this.add("-activate", source, "ability: Trap-Jaw");
        target.addVolatile("partiallytrapped");
      }
    },
    flags: { breakable: 1 },
    name: "Trap-Jaw",
    rating: 3.5,
    num: -3261
}