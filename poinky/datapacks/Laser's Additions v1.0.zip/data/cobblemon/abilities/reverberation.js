{
  onTryHitPriority: 1,
  onTryHit(target, source, move) {
    if (target !== source && move.flags["sound"]) {
      if (!this.boost({ atk: 1 })) {
        this.add("-immune", target, "[from] ability: Reverberation");
      }
      return null;
    }
  },
  flags: { breakable: 1 },
  name: "Reverberation",
  rating: 3.5,
  num: -3254
}