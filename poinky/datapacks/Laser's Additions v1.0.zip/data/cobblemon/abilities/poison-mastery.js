{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Poison"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Poison") {
        if (!this.boost({ spd: 1 })) {
          this.add("-immune", target, "[from] ability: Poison Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Poison") {
        this.boost({ spd: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Poison Mastery",
    rating: 3.5,
    num: -3217
  }