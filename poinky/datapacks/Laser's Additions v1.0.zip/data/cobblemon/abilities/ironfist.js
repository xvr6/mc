{
  onBasePowerPriority: 23,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["punch"]) {
      this.debug("Iron Fist boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Iron Fist",
  rating: 3,
  num: 89
}