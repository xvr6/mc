{
    onModifySpe(spe) {
      if (this.field.isTerrain("mistyterrain")) {
        return this.chainModify(2);
      }
    },
    flags: {},
    name: "Mist Rider",
    rating: 3,
    num: -3241
}