{
  onTryAddVolatile(status, target, source, effect) {
    if (["encore", "taunt", "torment"].includes(status.id)) {
      if (effect.effectType === "Move") {
        const effectHolder = this.effectState.target;
        this.add("-block", target, "ability: Recluse", "[of] " + effectHolder);
      }
      return null;
    }
  },
  onTryBoost(boost, target, source, effect) {
    if (effect.name === "Intimidate" && boost.atk) {
      this.boost({ spe: -1 }, target, target, null, false, true);
    }
  },
  flags: { breakable: 1 },
  name: "Recluse",
  rating: 2,
  num: -3229
}