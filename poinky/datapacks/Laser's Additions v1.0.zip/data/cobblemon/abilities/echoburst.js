{
    onDamagingHit(damage, target, source, move) {
      const side = source.isAlly(target) ? source.side.foe : source.side;
      const echoShards = side.sideConditions["echoshards"];
      if (move.category === "Physical" && (!echoShards || echoShards.layers < 1)) {
        this.add("-activate", target, "ability: Echo Burst");
        side.addSideCondition("echoshards", target);
      }
    },
    flags: {},
    name: "Echo Burst",
    rating: 3.5,
    num: -3256
}