{
    onAfterMoveSecondarySelfPriority: -1,
    onAfterMoveSecondarySelf(pokemon, target, move) {
    	if (move.flags["bite"] && move.totalDamage && !pokemon.forceSwitchFlag) {
    		this.heal(move.totalDamage / 2, pokemon);
    	}
    },
    flags: {},
    name: "Great Hunger",
    rating: 3.5,
    num: -3240
}