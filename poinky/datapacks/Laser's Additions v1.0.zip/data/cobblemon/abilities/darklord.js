{
    onModifyAtkPriority: 5,
    onModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Dark") {
        this.debug("Dark Lord boost");
        return this.chainModify(1.5);
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(atk, attacker, defender, move) {
      if (move.type === "Dark") {
        this.debug("Dark Lord boost");
        return this.chainModify(1.5);
      }
    },
    onSourceModifyAtkPriority: 5,
    onSourceModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Dark") {
        this.debug("Dark Lord weaken");
        return this.chainModify(0.5);
      }
    },
    onSourceModifySpAPriority: 5,
    onSourceModifySpA(atk, attacker, defender, move) {
      if (move.type === "Dark") {
        this.debug("Dark Lord weaken");
        return this.chainModify(0.5);
      }
    },
    flags: {},
    name: "Dark Lord",
    rating: 3.5,
    num: -3225
  }