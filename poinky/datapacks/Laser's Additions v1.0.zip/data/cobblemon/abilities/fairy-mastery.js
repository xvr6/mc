{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Fairy"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Fairy") {
        if (!this.boost({ spd: 1 })) {
          this.add("-immune", target, "[from] ability: Fairy Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Fairy") {
        this.boost({ spd: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Fairy Mastery",
    rating: 3.5,
    num: -3205
  }