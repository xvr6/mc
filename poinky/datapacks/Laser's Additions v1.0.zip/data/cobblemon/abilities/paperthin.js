{
  onEffectiveness(typeMod, target, type, move) {
    if (move.type === "Water" && type === "Grass")
      return 1;
  },
  onDamagingHit(damage, target, source, move) {
    if (["Water"].includes(move.type) && !target.volatiles["burning"]) {
      target.addVolatile("soggy");
    } else if (["Water"].includes(move.type) && target.volatiles["burning"]) {
      target.removeVolatile("burning");
    }
    if (["Fire"].includes(move.type) && !target.volatiles["soggy"]) {
      target.addVolatile("burning");
    } else if (["Fire"].includes(move.type) && target.volatiles["soggy"]) {
      target.removeVolatile("soggy");
    }
  },
  onWeather(target, source, effect) {
    if (target.hasItem("utilityumbrella"))
      return;
    if (effect.id === "raindance" || effect.id === "primordialsea") {
      if (target.volatiles["burning"]) {
        target.removeVolatile("burning");
      } else {
        target.addVolatile("soggy");
      }
    }
  },
  onSetStatus(status, target, source, effect) {
    if (status.id !== "brn")
      return;
    if (effect?.status) {
      if (target.volatiles["soggy"]) {
        this.add("-immune", target, "[from] move: Soggy");
        return false;
      } else {
        target.addVolatile("burning");
      }
    }
  },
  flags: { breakable: 1 },
  name: "Paper Thin",
  rating: 3.5,
  num: -3226
}
