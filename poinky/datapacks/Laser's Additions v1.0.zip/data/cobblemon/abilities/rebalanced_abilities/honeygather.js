{
    onResidualOrder: 28,
    onResidualSubOrder: 2,
    onResidual(pokemon) {
      if (pokemon.activeTurns) {
        if (pokemon.volatiles["honeygather"] && pokemon.volatiles["honeygather"].layers >= 3) {
          return false;
        } else {
          this.add("-activate", pokemon, "ability: Honey Gather");
          pokemon.addVolatile("honeygather");
        }
      }
    },
    flags: {},
    name: "Honey Gather",
    rating: 0,
    num: 118
}