{
    onModifyMove(move) {
      if (move.flags["contact"])
        delete move.flags["protect"];
    },
    onModifyAtkPriority: 5,
    onModifyAtk(atk, attacker, defender, move) {
      if (defender.volatiles["protect","banefulbunker","burningbulwark","kingsshield","matblock","maxguard","obstruct","silktrap","spikyshield","shelter"]) {
        this.debug("Unseen Fist nerf");
        return this.chainModify(0.5);
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(atk, attacker, defender, move) {
      if (defender.volatiles["protect","banefulbunker","burningbulwark","kingsshield","matblock","maxguard","obstruct","silktrap","spikyshield","shelter"]) {
        this.debug("Unseen Fist nerf");
        return this.chainModify(0.5);
      }
    },
    flags: {},
    name: "Unseen Fist",
    rating: 2,
    num: 260
}