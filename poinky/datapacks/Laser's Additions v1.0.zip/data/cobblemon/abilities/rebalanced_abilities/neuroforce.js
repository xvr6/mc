{
    onModifyDamage(damage, source, target, move) {
      if (move && target.getMoveHitData(move).typeMod > 0) {
        return this.chainModify([move.hasAuraBreak ? 3072 : 5120, 4096]);
      }
    },
    flags: {},
    name: "Neuroforce",
    rating: 2.5,
    num: 233
}