{
    onResidualOrder: 5,
    onResidualSubOrder: 3,
    onResidual(pokemon) {
      for (const ally of pokemon.alliesAndSelf()) {
        if (ally.status && this.randomChance(5, 10)) {
          this.add("-activate", pokemon, "ability: Healer");
          ally.cureStatus();
        }
      }
    },
    flags: {},
    name: "Healer",
    rating: 0,
    num: 131
}