{
    onTryAddVolatile(status, pokemon) {
      if (status.id === "flinch")
        return null;
    },
    onTryHit(pokemon, target, move) {
      if (move.id === "partingshot") {
        this.add("-immune", pokemon, "[from] ability: Inner Focus");
        return null;
      }
    },
    onTryBoost(boost, target, source, effect) {
      if (effect.name === "Intimidate" && boost.atk) {
        delete boost.atk;
        this.add("-fail", target, "unboost", "Attack", "[from] ability: Inner Focus", "[of] " + target);
      }
    },
    flags: { breakable: 1 },
    name: "Inner Focus",
    rating: 1,
    num: 39
}