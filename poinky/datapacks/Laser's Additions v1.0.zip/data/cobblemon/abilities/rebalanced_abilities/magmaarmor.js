{
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Water") {
        this.add("-immune", target, "[from] ability: Magma Armor");
        return null;
      }
    },
    onUpdate(pokemon) {
      if (pokemon.status === "frz") {
        this.add("-activate", pokemon, "ability: Magma Armor");
        pokemon.cureStatus();
      }
    },
    onImmunity(type, pokemon) {
      if (type === "frz")
        return false;
    },
    flags: { breakable: 1 },
    name: "Magma Armor",
    rating: 0.5,
    num: 40
}