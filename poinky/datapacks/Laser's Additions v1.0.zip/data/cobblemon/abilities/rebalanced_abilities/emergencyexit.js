{
    onEmergencyExit(target) {
      if (!this.canSwitch(target.side) || target.forceSwitchFlag || target.switchFlag)
        return;
      for (const side of this.sides) {
        for (const active of side.active) {
          active.switchFlag = false;
        }
      }
      if (!target.volatiles["noretreat"]) {
        target.switchFlag = true;
        this.add("-activate", target, "ability: Emergency Exit");
      }
    },
    flags: {},
    name: "Emergency Exit",
    rating: 1,
    num: 194
}