{
    onModifyWeight(weighthg) {
      return this.trunc(weighthg / 2);
    },
    onModifySpePriority: 5,
    onModifySpe(spe, pokemon) {
      return this.chainModify(1.5);
    },
    flags: { breakable: 1 },
    name: "Light Metal",
    rating: 1,
    num: 135
}