{
    onStart(pokemon) {
      if (this.suppressingAbility(pokemon))
        return;
      this.add("-ability", pokemon, "Aura Break");
    },
    onAnyTryPrimaryHit(target, source, move) {
      if (target === source || move.category === "Status")
        return;
      move.hasAuraBreak = true;
    },
    onModifyMove(move) {
      move.ignoreAbility = true;
    },
    flags: { breakable: 1 },
    name: "Aura Break",
    rating: 1,
    num: 188
}