{
    onSourceModifyAtkPriority: 6,
    onSourceModifyAtk(atk, attacker, defender, move) {
      if (this.field.isWeather(["snow", "hail"])) {
        if (move.type === "Fire") {
          this.debug("Snow Guard weaken");
          return this.chainModify(0.5);
        }
      }
    },
    onSourceModifySpAPriority: 5,
    onSourceModifySpA(atk, attacker, defender, move) {
      if (this.field.isWeather(["snow", "hail"])) {
        if (move.type === "Fire") {
          this.debug("Snow Guard weaken");
          return this.chainModify(0.5);
        }
      }
    },
    onModifySpDPriority: 6,
    onModifySpD(spd, pokemon) {
      if (["snow", "hail"].includes(pokemon.effectiveWeather())) {
        return this.chainModify(1.5);
      }
    },
    onSetStatus(status, target, source, effect) {
      if (["snow", "hail"].includes(target.effectiveWeather())) {
        if (effect?.status) {
          this.add("-immune", target, "[from] ability: Snow Guard");
        }
        return false;
      }
    },
    onTryAddVolatile(status, target) {
      if (status.id === "yawn" && ["snow", "hail"].includes(target.effectiveWeather())) {
        this.add("-immune", target, "[from] ability: Snow Guard");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Snow Guard",
    rating: 3.5,
    num: -3228
  }