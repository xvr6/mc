{
    onResidualOrder: 5,
    onResidualSubOrder: 3,
    onResidual(pokemon) {
      if (pokemon.status && ["raindance", "primordialsea"].includes(pokemon.effectiveWeather())) {
        this.debug("hydration");
        this.add("-activate", pokemon, "ability: Hydration");
        pokemon.cureStatus();
      }
    },
    onModifySpDPriority: 6,
    onModifySpD(spd, pokemon) {
      if (["rain", "primordialsea"].includes(pokemon.effectiveWeather())) {
        return this.chainModify(1.25);
      }
    },
    flags: {},
    name: "Hydration",
    rating: 1.5,
    num: 93
}