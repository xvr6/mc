{
    onBasePowerPriority: 19,
    onBasePower(basePower, attacker, defender, move) {
      if (move.flags["pulse"]) {
        return this.chainModify([move.hasAuraBreak ? 0.75 : 1.5]);
      }
    },
    flags: {},
    name: "Mega Launcher",
    rating: 3,
    num: 178
}