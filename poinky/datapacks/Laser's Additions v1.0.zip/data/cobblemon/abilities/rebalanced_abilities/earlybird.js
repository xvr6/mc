{
    onModifyPriority(priority, pokemon, target, move) {
      if (move.priority > 0.1)
        return priority + 3;
    },
    flags: {},
    name: "Early Bird",
    rating: 1.5,
    num: 48
}