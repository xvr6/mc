{
    onModifyMove(move) {
      move.infiltrates = true;
    },
    onAnyModifyBoost(boosts, pokemon) {
      const infiltratorUser = this.effectState.target;
      if (infiltratorUser === pokemon)
        return;
      if (infiltratorUser === this.activePokemon && pokemon === this.activeTarget) {
        boosts["def"] = 0;
        boosts["spd"] = 0;
      }
    },
    flags: {},
    name: "Infiltrator",
    rating: 2.5,
    num: 151
}