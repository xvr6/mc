{
    onStart(pokemon) {
      for (const target of pokemon.foes()) {
        if (target.item) {
          this.add("-item", target, target.getItem().name, "[from] ability: Frisk", "[of] " + pokemon, "[identify]");
        }
      }
      let activated = false;
      for (const target of pokemon.adjacentFoes()) {
        if (target.volatiles["substitute"]) {
          this.add("-immune", target);
        } else {
          target.addVolatile("embargo", this.effectState.target);
        }
      }
    },
    flags: {},
    name: "Frisk",
    rating: 1.5,
    num: 119
}