{
    onTryBoost(boost, target, source, effect) {
      if (source && target === source)
        return;
      if (boost.atk && boost.atk < 0) {
        delete boost.atk;
        target.addVolatile("focusenergy");
        if (!effect.secondaries) {
          this.add("-fail", target, "unboost", "Attack", "[from] ability: Hyper Cutter", "[of] " + target);
        }
      }
    },
    onTryHit(pokemon, target, move) {
      if (move.id === "partingshot" || move.id === "taunt") {
        this.add("-immune", pokemon, "[from] ability: Own Tempo");
        pokemon.addVolatile("focusenergy");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Hyper Cutter",
    rating: 1.5,
    num: 52
}