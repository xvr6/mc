{
    onStart(pokemon) {
      if (pokemon.side.sideConditions["tailwind"]) {
        pokemon.addVolatile("charge");
      }
    },
    onTryHit(target, source, move) {
      if (target !== source && move.flags["wind"]) {
        if (!target.addVolatile("charge")) {
          this.add("-immune", target, "[from] ability: Wind Power");
        }
        return null;
      }
    },
    onAllySideConditionStart(target, source, sideCondition) {
      const pokemon = this.effectState.target;
      if (sideCondition.id === "tailwind") {
        pokemon.addVolatile("charge");
      }
    },
    flags: {},
    name: "Wind Power",
    rating: 1,
    num: 277
}