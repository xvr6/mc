{
    onModifyAtkPriority: 5,
    onModifyAtk(atk, pokemon) {
      for (const allyActive of pokemon.allies()) {
        if (allyActive.hasAbility(["telepathy"])) {
          return this.chainModify(1.5);
        }
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(spa, pokemon) {
      for (const allyActive of pokemon.allies()) {
        if (allyActive.hasAbility(["telepathy"])) {
          return this.chainModify(1.5);
        }
      }
    },
    onTryHit(target, source, move) {
      if (target !== source && target.isAlly(source) && move.category !== "Status") {
        this.add("-activate", target, "ability: Telepathy");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Telepathy",
    rating: 0,
    num: 140
}