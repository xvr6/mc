{
  onModifySpAPriority: 5,
  onModifySpA(spa, pokemon) {
    for (const allyActive of pokemon.allies()) {
      if (allyActive.hasAbility(["minus", "plus"])) {
        return this.chainModify(1.5);
      }
    }
  },
  onModifyAtkPriority: 5,
  onModifyAtk(atk, pokemon) {
    for (const allyActive of pokemon.allies()) {
      if (allyActive.hasAbility(["minus", "plus"])) {
        return this.chainModify(1.5);
      }
    }
  },
  onModifyDefPriority: 5,
  onModifyDef(def, pokemon) {
    for (const allyActive of pokemon.allies()) {
      if (allyActive.hasAbility(["minus"])) {
         return this.chainModify(1.5);
      }
    }
  },
  onModifySpDPriority: 5,
  onModifySpD(spd, pokemon) {
    for (const allyActive of pokemon.allies()) {
      if (allyActive.hasAbility(["minus"])) {
         return this.chainModify(1.5);
      }
    }
  },
  flags: {},
  name: "Plus",
  rating: 0,
  num: 57
}