{
    onModifyWeightPriority: 1,
    onModifyWeight(weighthg) {
      return weighthg * 2;
    },
    onTryHit(pokemon, target, move) {
      if (move.id === "lowkick" || move.id === "grassknot" || move.id === "lowsweep") {
        this.add("-immune", pokemon, "[from] ability: Heavy Metal");
        return null;
      }
    },
    onModifySpePriority: 5,
    onModifySpe(spe, pokemon) {
      return this.chainModify(0.5);
    },
    flags: { breakable: 1 },
    name: "Heavy Metal",
    rating: 0,
    num: 134
}