{
    onUpdate(pokemon) {
      if (pokemon.status === "par") {
        this.add("-activate", pokemon, "ability: Limber");
        pokemon.cureStatus();
      }
      if (pokemon.volatiles["partiallytrapped"]) {
        this.add("-activate", pokemon, "ability: Limber");
        pokemon.removeVolatile("partiallytrapped");
      }
      if (pokemon.volatiles["trapped"]) {
        this.add("-activate", pokemon, "ability: Limber");
        pokemon.removeVolatile("trapped");
      }
    },
    onTryAddVolatile(status, target, source, effect) {
      if (["partiallytrapped", "trapped"].includes(status.id)) {
        if (effect.effectType === "Move") {
          const effectHolder = this.effectState.target;
          this.add("-block", target, "ability: Limber", "[of] " + effectHolder);
        }
        return null;
      }
    },
    onSetStatus(status, target, source, effect) {
      if (status.id !== "par")
        return;
      if (effect?.status) {
        this.add("-immune", target, "[from] ability: Limber");
      }
      return false;
    },
    onTryBoost(boost, target, source, effect) {
      if (source && target === source)
        return;
      if (boost.spe && boost.spe < 0) {
        delete boost.spe;
        if (!effect.secondaries) {
          this.add("-fail", target, "unboost", "Speed", "[from] ability: Limber", "[of] " + target);
        }
      }
    },
    flags: { breakable: 1 },
    name: "Limber",
    rating: 2,
    num: 7
}