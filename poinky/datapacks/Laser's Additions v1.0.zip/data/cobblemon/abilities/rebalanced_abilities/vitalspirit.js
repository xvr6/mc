{
    onUpdate(pokemon) {
      if (pokemon.status === "slp") {
        this.add("-activate", pokemon, "ability: Vital Spirit");
        pokemon.cureStatus();
        pokemon.addVolatile("focusenergy");
      }
    },
    onSetStatus(status, target, source, effect) {
      if (status.id !== "slp")
        return;
      if (effect?.status) {
        this.add("-immune", target, "[from] ability: Vital Spirit");
        target.addVolatile("focusenergy");
      }
      return false;
    },
    onTryAddVolatile(status, target) {
      if (status.id === "yawn") {
        this.add("-immune", target, "[from] ability: Vital Spirit");
        target.addVolatile("focusenergy");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Vital Spirit",
    rating: 1.5,
    num: 72
}