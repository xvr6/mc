{
    onModifyAtkPriority: 5,
    onModifyAtk(atk) {
      return this.modify(atk, 1.5);
    },
    onModifySpAPriority: 5,
    onModifySpA(spa) {
      return this.modify(spa, 1.5);
    },
    onSourceModifyAccuracyPriority: -1,
    onSourceModifyAccuracy(accuracy, target, source, move) {
      if (move.category === "Physical" && typeof accuracy === "number") {
        return this.chainModify([3686, 4096]);
      }
    },
    flags: {},
    name: "Hustle",
    rating: 3.5,
    num: 55
}