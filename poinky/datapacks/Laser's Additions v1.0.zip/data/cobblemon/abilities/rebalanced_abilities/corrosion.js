{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Poison"] = true;
      }
    },
    flags: {},
    name: "Corrosion",
    rating: 2.5,
    num: 212
}