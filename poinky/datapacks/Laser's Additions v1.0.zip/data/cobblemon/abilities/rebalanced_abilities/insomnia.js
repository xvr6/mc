{
    onUpdate(pokemon) {
      if (pokemon.status === "slp") {
        this.add("-activate", pokemon, "ability: Insomnia");
        pokemon.cureStatus();
        this.boost({ atk: 1, spa: 1 });
      }
    },
    onSetStatus(status, target, source, effect) {
      if (status.id !== "slp")
        return;
      if (effect?.status) {
        this.add("-immune", target, "[from] ability: Insomnia");
        this.boost({ atk: 1, spa: 1 });
      }
      return false;
    },
    onTryAddVolatile(status, target) {
      if (status.id === "yawn") {
        this.add("-immune", target, "[from] ability: Insomnia");
        this.boost({ atk: 1, spa: 1 });
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Insomnia",
    rating: 1.5,
    num: 15
}