{
    onTryBoost(boost, target, source, effect) {
      if (source && target === source)
        return;
      if (boost.def && boost.def < 0) {
        delete boost.def;
        if (!effect.secondaries && effect.id !== "octolock") {
          this.add("-fail", target, "unboost", "Defense", "[from] ability: Big Pecks", "[of] " + target);
        }
      }
      let b;
      for (b in boost) {
        if (effect.name === "Intimidate" && boost.atk && boost[b] < 0) {
          if (target.boosts[b] === -6)
            continue;
          const negativeBoost = {};
          negativeBoost[b] = boost[b];
          delete boost[b];
          if (source.hp) {
            this.add("-ability", target, "Big Pecks");
            this.boost(negativeBoost, source, target, null, true);
          }
        }
        if (effect.name === "Parting Shot" && boost.atk && boost[b] < 0) {
          if (target.boosts[b] === -6)
            continue;
          const negativeBoost = {};
          negativeBoost[b] = boost[b];
          delete boost[b];
          if (source.hp) {
            this.add("-ability", target, "Big Pecks");
            this.boost(negativeBoost, source, target, null, true);
          }
        }
        if (effect.name === "Parting Shot" && boost.spa && boost[b] < 0) {
          if (target.boosts[b] === -6)
            continue;
          const negativeBoost = {};
          negativeBoost[b] = boost[b];
          delete boost[b];
          if (source.hp) {
            this.boost(negativeBoost, source, target, null, true);
          }
        }
      }
    },
    flags: { breakable: 1 },
    name: "Big Pecks",
    rating: 0.5,
    num: 145
}