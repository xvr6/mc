{
    onSourceModifyAtkPriority: 6,
    onSourceModifyAtk(atk, attacker, defender, move) {
      if (this.field.isWeather(["sunnyday", "desolateland"])) {
        if (move.type === "Fire") {
          this.debug("Leaf Guard weaken");
          return this.chainModify(0.5);
        }
      }
    },
    onSourceModifySpAPriority: 5,
    onSourceModifySpA(atk, attacker, defender, move) {
      if (this.field.isWeather(["sunnyday", "desolateland"])) {
        if (move.type === "Fire") {
          this.debug("Leaf Guard weaken");
          return this.chainModify(0.5);
        }
      }
    },
    onModifyDefPriority: 6,
    onModifyDef(def, pokemon) {
      if (["sunnyday", "desolateland"].includes(pokemon.effectiveWeather())) {
        return this.chainModify(1.25);
      }
    },
    onSetStatus(status, target, source, effect) {
      if (["sunnyday", "desolateland"].includes(target.effectiveWeather())) {
        if (effect?.status) {
          this.add("-immune", target, "[from] ability: Leaf Guard");
        }
        return false;
      }
    },
    onTryAddVolatile(status, target) {
      if (status.id === "yawn" && ["sunnyday", "desolateland"].includes(target.effectiveWeather())) {
        this.add("-immune", target, "[from] ability: Leaf Guard");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Leaf Guard",
    rating: 0.5,
    num: 102
}