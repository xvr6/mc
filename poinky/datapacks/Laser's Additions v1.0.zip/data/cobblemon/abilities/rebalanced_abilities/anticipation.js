{
    onStart(pokemon, source) {
      for (const target of pokemon.foes()) {
        for (const moveSlot of target.moveSlots) {
          const move = this.dex.moves.get(moveSlot.move);
          if (move.category === "Status")
            continue;
          const moveType = move.id === "hiddenpower" ? target.hpType : move.type;
          if (this.dex.getImmunity(moveType, pokemon) && this.dex.getEffectiveness(moveType, pokemon) > 0 || move.ohko) {
            this.add("-ability", pokemon, "Anticipation");
            this.boost({ def: 1, spd: 1 }, source, source, null, true);
            return;
          }
        }
      }
    },
    flags: {},
    name: "Anticipation",
    rating: 0.5,
    num: 107
}