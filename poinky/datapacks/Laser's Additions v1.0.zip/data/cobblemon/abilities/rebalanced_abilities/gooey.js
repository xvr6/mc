{
    onDamagingHit(damage, target, source, move) {
      if (this.checkMoveMakesContact(move, source, target, true)) {
        this.add("-ability", target, "Gooey");
        this.boost({ spe: -1 }, source, target, null, true);
      }
      if (move.category === "Special" && move.type !== "Water") {
        this.add("-ability", target, "Gooey");
        target.addVolatile("slickslime");
      }
    },
    flags: {},
    name: "Gooey",
    rating: 2,
    num: 183
}