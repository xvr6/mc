{
    onStart(pokemon) {
      this.add("-ability", pokemon, "Supersweet Syrup");
      let activated = false;
      for (const target of pokemon.adjacentFoes()) {
        if (!activated) {
          this.add("-ability", pokemon, "Supersweet Syrup", "boost");
          activated = true;
        }
        if (target.volatiles["substitute"]) {
          this.add("-immune", target);
        } else {
          this.boost({ evasion: -1 }, target, pokemon, null, true);
        }
      }
    },
    flags: {},
    name: "Supersweet Syrup",
    rating: 1.5,
    num: 306
}