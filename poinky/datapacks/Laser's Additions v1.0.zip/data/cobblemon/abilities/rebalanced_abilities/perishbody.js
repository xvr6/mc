{
    onDamagingHit(damage, target, source, move) {
      if (!this.checkMoveMakesContact(move, source, target))
        return;
      let announced = false;
      for (const pokemon of [source]) {
        if (pokemon.volatiles["perishsong"])
          continue;
        if (!announced) {
          this.add("-ability", target, "Perish Body");
          announced = true;
        }
        pokemon.addVolatile("perishsong");
      }
    },
    flags: {},
    name: "Perish Body",
    rating: 1,
    num: 253
}