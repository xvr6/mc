{
    onModifyDefPriority: 6,
    onModifyDef(def) {
      return this.chainModify(2);
    },
    onModifyAtkPriority: 5,
    onModifyAtk(atk, attacker, defender, move) {
	  	if (move.overrideOffensiveStat === "def") {
        this.debug("Fur Coat boost");
        return this.chainModify(2);
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(spa, attacker, defender, move) {
    	if (move.overrideOffensiveStat === "def") {
        this.debug("Fur Coat boost");
        return this.chainModify(2);
      }
    },
    flags: { breakable: 1 },
    name: "Fur Coat",
    rating: 4,
    num: 169
}