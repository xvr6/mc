{
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Water") {
        if (!this.boost({ def: 2 })) {
          this.add("-immune", target, "[from] ability: Water Compaction");
        }
        return null;
      }
    },
    flags: {},
    name: "Water Compaction",
    rating: 1.5,
    num: 195
}