{
    onTrapPokemonPriority: -10,
    onTrapPokemon(pokemon) {
    	pokemon.trapped = pokemon.maybeTrapped = false;
    },
    flags: {},
    name: "Run Away",
    rating: 0,
    num: 50
}