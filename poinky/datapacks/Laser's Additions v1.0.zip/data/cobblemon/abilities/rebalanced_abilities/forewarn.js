{
    onStart(pokemon) {
      let warnMoves = [];
      let warnBp = 1;
      for (const target of pokemon.foes()) {
        for (const moveSlot of target.moveSlots) {
          const move = this.dex.moves.get(moveSlot.move);
          let bp = move.basePower;
          if (move.ohko)
            bp = 150;
          if (move.id === "counter" || move.id === "metalburst" || move.id === "mirrorcoat")
            bp = 120;
          if (bp === 1)
            bp = 80;
          if (!bp && move.category !== "Status")
            bp = 80;
          if (bp > warnBp) {
            warnMoves = [[move, target]];
            warnBp = bp;
          } else if (bp === warnBp) {
            warnMoves.push([move, target]);
          }
        }
      }
      if (!warnMoves.length)
        return;
      const [warnMoveName, warnTarget] = this.sample(warnMoves);
      this.add("-activate", pokemon, "ability: Forewarn", warnMoveName, "[of] " + warnTarget);
    },
    onTryHit(pokemon, target, move) {
      if (move.id === "futuresight" || move.id === "doomdesire" || move.priority > 0.1) {
        this.add("-ability", pokemon, "Forewarn");
        this.add("-block", pokemon, "ability: Forewarn", "[of] " + this.effectState.target);
        return null;
      }
    },
    onTryBoost(boost, target, source, effect) {
      if (effect.name === "Net Caster" && boost.spe) {
        delete boost.spe;
        this.add("-ability", target, "Forewarn");
        this.add("-fail", target, "unboost", "Speed", "[from] ability: Forewarn", "[of] " + target);
      }
    },
    flags: {},
    name: "Forewarn",
    rating: 0.5,
    num: 108
}