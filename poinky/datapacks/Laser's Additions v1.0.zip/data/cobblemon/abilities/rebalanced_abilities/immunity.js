{
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Poison") {
        this.add("-immune", target, "[from] ability: Immunity");
        return null;
      }
    },
    onUpdate(pokemon) {
      if (pokemon.status === "psn" || pokemon.status === "tox") {
        this.add("-activate", pokemon, "ability: Immunity");
        pokemon.cureStatus();
      }
    },
    onSetStatus(status, target, source, effect) {
      if (status.id !== "psn" && status.id !== "tox")
        return;
      if (effect?.status) {
        this.add("-immune", target, "[from] ability: Immunity");
      }
      return false;
    },
    flags: { breakable: 1 },
    name: "Immunity",
    rating: 2,
    num: 17
}