{
    onFlinch(pokemon) {
      this.boost({ spe: 1 });
    },
    onTryHit(pokemon, target, move) {
      if (move.id === "partingshot") {
        this.add("-immune", pokemon, "[from] ability: Steadfast");
        this.boost({ spe: 1 }, pokemon, pokemon, null, false, true);
        return null;
      }
    },
    onTryBoost(boost, target, source, effect) {
      if (effect.name === "Intimidate" && boost.atk) {
        delete boost.atk;
        this.boost({ spe: 1 }, target, target, null, false, true);
      }
    },
    flags: {},
    name: "Steadfast",
    rating: 1,
    num: 80
}