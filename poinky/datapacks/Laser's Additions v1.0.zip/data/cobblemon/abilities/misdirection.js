{
  onFoeRedirectTarget(target, source, source2, move) {
    const redirectTarget = ["randomNormal", "adjacentFoe"].includes(move.target) ? "normal" : move.target;
    if (this.validTarget(this.effectState.target, source, redirectTarget)) {
      if (move.smartTarget)
        move.smartTarget = false;
      if (this.effectState.target !== target) {
        this.add("-activate", this.effectState.target, "ability: Misdirection");
      }
      return this.effectState.target;
    }
  },
  onDisableMove(pokemon) {
  	for (const moveSlot of pokemon.moveSlots) {
  		const move = this.dex.moves.get(moveSlot.id);
  		if (move.stallingMove) {
  			pokemon.disableMove(moveSlot.id);
  		}
  	}
  },
  flags: { breakable: 1 },
  name: "Misdirection",
  rating: 3.5,
  num: -3227
}
