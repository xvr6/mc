{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Rock"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Rock") {
        if (!this.boost({ def: 1 })) {
          this.add("-immune", target, "[from] ability: Rock Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Rock") {
        this.boost({ def: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Rock Mastery",
    rating: 3.5,
    num: -3219
  }