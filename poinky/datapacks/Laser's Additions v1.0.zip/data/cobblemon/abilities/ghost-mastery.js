{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Ghost"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Ghost") {
        if (!this.boost({ spa: 1 })) {
          this.add("-immune", target, "[from] ability: Ghost Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Ghost") {
        this.boost({ spa: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Ghost Mastery",
    rating: 3.5,
    num: -3210
  }