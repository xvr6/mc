{
  onModifySpAPriority: 1,
  onModifySpA(spa) {
  	return this.chainModify(1.5);
  },
  onDisableMove(pokemon) {
  	for (const moveSlot of pokemon.moveSlots) {
  		const move = this.dex.moves.get(moveSlot.id);
  		if (move.category === 'Status' && move.id !== 'mefirst') {
  			pokemon.disableMove(moveSlot.id);
  		}
  	}
  },
  flags: {},
  name: "Mighty Mycelium",
  rating: 3.5,
  num: -3257
}