{
  onModifySpAPriority: 5,
  onModifySpA(spa, pokemon) {
    if (pokemon.status) {
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Resilient",
  rating: 3.5,
  num: -3253
}