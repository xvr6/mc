{
    onAllyBasePowerPriority: 22,
    onAllyBasePower(basePower, attacker, defender, move) {
      if (move.type === "Bug" || move.type === "Steel") {
        this.debug("Hivemind boost");
        return this.chainModify([5461, 4096]);
      }
    },
    flags: {},
    name: "Hivemind",
    rating: 4,
    num: -3233
}