{
  onBasePowerPriority: 7,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["sound"]) {
      this.debug("Shrieker boost");
      return this.chainModify([5325, 4096]);
    }
  },
  onTryHit(target, source, move) {
    if (target !== source && move.flags["sound"]) {
      this.add("-immune", target, "[from] ability: Shrieker");
      return null;
    }
  },
  onAllyTryHitSide(target, source, move) {
    if (move.flags["sound"]) {
      this.add("-immune", this.effectState.target, "[from] ability: Shrieker");
    }
  },
  flags: { breakable: 1 },
  name: "Shrieker",
    rating: 3.5,
    num: -3220
}