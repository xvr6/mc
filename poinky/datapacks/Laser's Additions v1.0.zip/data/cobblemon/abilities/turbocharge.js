{
    onModifyAtkPriority: 5,
    onModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Electric") {
        this.debug("Turbocharge boost");
        return this.chainModify(1.5);
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(atk, attacker, defender, move) {
      if (move.type === "Electric") {
        this.debug("Turbocharge boost");
        return this.chainModify(1.5);
      }
    },
    onSourceModifyAtkPriority: 6,
    onSourceModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Electric") {
        this.debug("Turbocharge weaken");
        return this.chainModify(0.5);
      }
    },
    onSourceModifySpAPriority: 5,
    onSourceModifySpA(atk, attacker, defender, move) {
      if (move.type === "Electric") {
        this.debug("Turbocharge weaken");
        return this.chainModify(0.5);
      }
    },
    onDamagingHit(damage, target, source, move) {
      if (["Electric"].includes(move.type)) {
        this.boost({ spe: 1 });
      }
    },
    flags: { breakable: 1 },
    name: "Turbocharge",
    rating: 3.5,
    num: -3229
}