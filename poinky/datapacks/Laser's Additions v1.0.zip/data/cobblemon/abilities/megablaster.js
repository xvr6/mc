{
  onBasePowerPriority: 19,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["beam"]) {
      this.debug("Mega Blaster boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Mega Blaster",
    rating: 3.5,
    num: -3236
}