{
    onTryHit(target, source, move) {
      if (target !== source && move.flags["bite"]) {
        this.add("-immune", target, "[from] ability: Tasty Aroma");
        return null;
      }
    },
    onFoeRedirectTarget(target, source, source2, move) {
      if (!move.flags["bite"] || move.flags["pledgecombo"])
        return;
      const redirectTarget = ["randomNormal", "adjacentFoe"].includes(move.target) ? "normal" : move.target;
      if (this.validTarget(this.effectState.target, source, redirectTarget)) {
        if (move.smartTarget)
          move.smartTarget = false;
        if (this.effectState.target !== target) {
          this.add("-activate", this.effectState.target, "ability: Tasty Aroma");
        }
        return this.effectState.target;
      }
    },
    flags: {},
    name: "Tasty Aroma",
    rating: 3.5,
    num: -3263
}