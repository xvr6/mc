{
    onModifyDefPriority: 6,
    onModifyDef(def, pokemon) {
      if (["sandstorm"].includes(pokemon.effectiveWeather())) {
        return this.chainModify(1.25);
      }
    },
    onSetStatus(status, target, source, effect) {
      if (["sandstorm"].includes(target.effectiveWeather())) {
        if (effect?.status) {
          this.add("-immune", target, "[from] ability: Sand Guard");
        }
        return false;
      }
    },
    onTryAddVolatile(status, target) {
      if (status.id === "yawn" && ["snow", "hail"].includes(target.effectiveWeather())) {
        this.add("-immune", target, "[from] ability: Sand Guard");
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Sand Guard",
    rating: 3.5,
    num: -3255
}