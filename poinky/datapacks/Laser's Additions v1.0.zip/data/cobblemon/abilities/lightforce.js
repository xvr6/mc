{
    onBasePowerPriority: 19,
    onBasePower(basePower, attacker, defender, move) {
      if (move.flags["light"]) {
        this.debug("Lightforce boost");
        return this.chainModify([move.hasAuraBreak ? 3072 : 5461, 4096]);
      }
    },
    flags: {},
    name: "Lightforce",
    rating: 3.5,
    num: -3239
}