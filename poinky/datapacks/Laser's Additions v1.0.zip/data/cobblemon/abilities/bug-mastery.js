{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Bug"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Bug") {
        if (!this.boost({ atk: 1 })) {
          this.add("-immune", target, "[from] ability: Bug Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Bug") {
        this.boost({ atk: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Bug Mastery",
    rating: 3.5,
    num: -3201
  }