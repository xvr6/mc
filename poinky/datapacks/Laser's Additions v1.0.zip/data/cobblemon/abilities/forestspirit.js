{
  onAllyBasePowerPriority: 22,
  onAllyBasePower(basePower, attacker, defender, move) {
    if (move.type === "Grass") {
      this.debug("Forest Spirit boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Forest Spirit",
    rating: 3.5,
    num: -3209
}