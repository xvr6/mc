{
    onBasePowerPriority: 19,
    onBasePower(basePower, attacker, defender, move) {
      if (move.flags["wind"]) {
        this.debug("Aeroforce boost");
        return this.chainModify([move.hasAuraBreak ? 3072 : 5461, 4096]);
      }
    },
    flags: {},
    name: "Aeroforce",
    rating: 3.5,
    num: -3247
}