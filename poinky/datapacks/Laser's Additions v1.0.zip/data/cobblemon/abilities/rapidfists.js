{
  onModifyPriority(priority, pokemon, target, move) {
    if (move?.flags["punch"])
      return priority + 3;
  },
  flags: {},
  name: "Rapid Fists",
  rating: 3.5,
  num: -3252
}