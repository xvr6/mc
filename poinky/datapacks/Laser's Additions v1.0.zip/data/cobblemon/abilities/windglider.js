{
    onStart(pokemon) {
      if (pokemon.side.sideConditions["tailwind"]) {
        this.boost({ spe: 1 }, pokemon, pokemon);
      }
    },
    onTryHit(target, source, move) {
      if (target !== source && move.flags["wind"]) {
        if (!this.boost({ spe: 1 }, target, target)) {
          this.add("-immune", target, "[from] ability: Wind Glider");
        }
        return null;
      }
    },
    onAllySideConditionStart(target, source, sideCondition) {
      const pokemon = this.effectState.target;
      if (sideCondition.id === "tailwind") {
        this.boost({ spe: 1 }, pokemon, pokemon);
      }
    },
    flags: { breakable: 1 },
    name: "Wind Glider",
    rating: 3.5,
    num: -3260
}