{
    onDamagingHit(damage, target, source, move) {
      if (move.type === "Dark") {
        this.boost({ spa: 1 });
      }
    },
    flags: {},
    name: "Rectitude",
    rating: 2.5,
    num: 154
}