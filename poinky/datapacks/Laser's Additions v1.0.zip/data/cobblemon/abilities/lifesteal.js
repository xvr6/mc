{
  onBasePowerPriority: 19,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["heal"]) {
      this.debug("Lifesteal boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Lifesteal",
    rating: 3.5,
    num: -3215
}