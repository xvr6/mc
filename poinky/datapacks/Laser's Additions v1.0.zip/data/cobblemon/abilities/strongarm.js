{
  onBasePowerPriority: 19,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["throwing"]) {
      this.debug("Strong Arm boost");
      return this.chainModify(1.5);
    }
  },
  onDragOutPriority: 1,
  onDragOut(pokemon) {
    this.add("-activate", pokemon, "ability: Strong Arm");
    return null;
  },
  flags: {},
  name: "Strong Arm",
  rating: 3.5,
  num: -3251
}