{
    onModifyDamage(damage, source, target, move) {
      if (target.getMoveHitData(move).typeMod < 0) {
        this.debug("Champion's Mask boost");
        return this.chainModify(2);
      }
    },
    flags: {},
    name: "Champion's Mask",
    rating: 3.5,
    num: -3263
}