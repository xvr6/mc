{
  onStart(source) {
    this.field.setTerrain("psychicterrain");
  },
  onResidualOrder: 5,
  onResidualSubOrder: 4,
  onResidual(pokemon) {
    if (this.field.isTerrain("psychicterrain")) {
   this.heal(pokemon.baseMaxhp / 16);
    }
  },
  flags: {},
  name: "Zen Domain",
  rating: 4,
  num: -3230
}