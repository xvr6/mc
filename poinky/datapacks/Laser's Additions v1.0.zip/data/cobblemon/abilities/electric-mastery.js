{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Electric"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Electric") {
        if (!this.boost({ spe: 1 })) {
          this.add("-immune", target, "[from] ability: Electric Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Electric") {
        this.boost({ spe: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Electric Mastery",
    rating: 3.5,
    num: -3204
  }