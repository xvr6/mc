{
    onModifyMovePriority: -5,
    onModifyMove(move) {
      if (!move.ignoreImmunity)
        move.ignoreImmunity = {};
      if (move.ignoreImmunity !== true) {
        move.ignoreImmunity["Grass"] = true;
        move.ignoreAbility = true;
      }
    },
    onTryHitPriority: 1,
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Grass") {
        if (!this.boost({ spa: 1 })) {
          this.add("-immune", target, "[from] ability: Grass Mastery");
        }
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (source === this.effectState.target || !target.isAlly(source))
        return;
      if (move.type === "Grass") {
        this.boost({ spa: 1 }, this.effectState.target);
      }
    },
    flags: { breakable: 1 },
    name: "Grass Mastery",
    rating: 3.5,
    num: -3211
  }