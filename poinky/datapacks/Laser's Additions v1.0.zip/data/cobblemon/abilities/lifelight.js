{
    onTryHit(target, source, move) {
      if (target !== source && move.flags["light"]) {
        if (!this.heal(target.baseMaxhp / 4)) {
          this.add("-immune", target, "[from] ability: Lifelight");
        }
        return null;
      }
    },
    flags: {},
    name: "Lifelight",
    rating: 3.5,
    num: -3238
}