{
    onModifyAtkPriority: 5,
    onModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Psychic") {
        this.debug("Intellectual boost");
        return this.chainModify(1.5);
      }
    },
    onModifySpAPriority: 5,
    onModifySpA(atk, attacker, defender, move) {
      if (move.type === "Psychic") {
        this.debug("Intellectual boost");
        return this.chainModify(1.5);
      }
    },
    onSourceModifyAtkPriority: 6,
    onSourceModifyAtk(atk, attacker, defender, move) {
      if (move.type === "Psychic") {
        this.debug("Intellectual weaken");
        return this.chainModify(0.5);
      }
    },
    onSourceModifySpAPriority: 5,
    onSourceModifySpA(atk, attacker, defender, move) {
      if (move.type === "Psychic") {
        this.debug("Intellectual weaken");
        return this.chainModify(0.5);
      }
    },
    flags: { breakable: 1 },
    name: "Intellectual",
    rating: 3.5,
    num: -3228
  }