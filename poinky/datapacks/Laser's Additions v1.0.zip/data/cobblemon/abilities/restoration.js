{
    onResidualOrder: 5,
    onResidualSubOrder: 4,
    onResidual(pokemon) {
      if (["sunnyday", "desolateland"].includes(pokemon.effectiveWeather()) && !pokemon.hasItem("utilityumbrella")) {
        this.heal(pokemon.baseMaxhp / 8);
      } else if (["sunnyday", "desolateland"].includes(pokemon.effectiveWeather()) && pokemon.hasItem("leftovers")) {
    	  this.heal(pokemon.baseMaxhp / 16);
      } else if (!pokemon.hasItem("leftovers")) {
    	  this.heal(pokemon.baseMaxhp / 16);
      } else {
        return;
      }
    },
    flags: {},
    name: "Restoration",
    rating: 3.5,
    num: -3248
}