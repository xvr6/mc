{
  onBasePowerPriority: 19,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["hammer"]) {
      this.debug("Hammer Time boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Hammer Time",
  rating: 3.5,
  num: -3245
}