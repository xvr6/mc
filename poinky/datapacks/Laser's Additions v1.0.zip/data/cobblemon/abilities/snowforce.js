{
    onBasePowerPriority: 21,
    onBasePower(basePower, attacker, defender, move) {
      if (this.field.isWeather(["snow", "hail"])) {
        if (move.type === "Ice") {
          this.debug("Snow Force boost");
          return this.chainModify(1.5);
        }
      }
    },
    onImmunity(type, pokemon) {
      if (type === "hail")
        return false;
    },
    flags: {},
    name: "Snow Force",
    rating: 4,
    num: -3234
}