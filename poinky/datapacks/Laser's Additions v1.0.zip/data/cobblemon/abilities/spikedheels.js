{
    onModifyCritRatio(critRatio, attacker, defender, move) {
      if (move.flags["kick"]) {
        this.debug("Spiked Heels boost");
        return critRatio + 2;
      }
    },
    flags: {},
    name: "Spiked Heels",
    rating: 3.5,
    num: -3249
}