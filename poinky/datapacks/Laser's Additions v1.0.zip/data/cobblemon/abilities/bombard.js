{
  onBasePowerPriority: 19,
  onBasePower(basePower, attacker, defender, move) {
    if (move.flags["bullet"]) {
      this.debug("Bombard boost");
      return this.chainModify(1.5);
    }
  },
  flags: {},
  name: "Bombard",
    rating: 3.5,
    num: -3200
}