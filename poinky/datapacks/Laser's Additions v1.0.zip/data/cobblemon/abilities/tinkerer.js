{
  onFoeModifyDef(def, target) {
    if (target.hasType("Steel")) {
      this.debug("Tinkerer Def drop");
      return this.chainModify(0.75);
    }
  },
  flags: {},
  name: "Tinkerer",
  rating: 3.5,
  num: -3246
}