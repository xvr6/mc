{
  onResidualOrder: 5,
  onResidualSubOrder: 4,
  onResidual(pokemon) {
    if (this.field.isTerrain("mistyterrain")) {
      this.heal(pokemon.baseMaxhp / 16);
    }
  },
  flags: {},
  name: "Sweet Dish",
  rating: 1.5,
  num: -3250
}