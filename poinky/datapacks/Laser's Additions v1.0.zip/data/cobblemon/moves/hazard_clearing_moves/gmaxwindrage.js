{
    num: 1e3,
    accuracy: true,
    basePower: 10,
    category: "Physical",
    isNonstandard: "Gigantamax",
    name: "G-Max Wind Rage",
    pp: 10,
    priority: 0,
    flags: {},
    isMax: "Corviknight",
    self: {
      onHit(source) {
        let success = false;
        const removeTarget = [
          "reflect",
          "lightscreen",
          "auroraveil",
          "safeguard",
          "mist",
          "spikes",
          "toxicspikes",
          "stealthrock",
          "stickyweb",
          "iceshards",
          "echoshards",
          "mirrorshield"
        ];
        const removeAll = ["spikes", "toxicspikes", "stealthrock", "stickyweb", "gmaxsteelsurge", "icespikes", "echoshards"];
        for (const targetCondition of removeTarget) {
          if (source.side.foe.removeSideCondition(targetCondition)) {
            if (!removeAll.includes(targetCondition))
              continue;
            this.add("-sideend", source.side.foe, this.dex.conditions.get(targetCondition).name, "[from] move: G-Max Wind Rage", "[of] " + source);
            success = true;
          }
        }
        for (const sideCondition of removeAll) {
          if (source.side.removeSideCondition(sideCondition)) {
            this.add("-sideend", source.side, this.dex.conditions.get(sideCondition).name, "[from] move: G-Max Wind Rage", "[of] " + source);
            success = true;
          }
        }
        this.field.clearTerrain();
        return success;
      }
    },
    secondary: null,
    target: "adjacentFoe",
    type: "Flying",
    contestType: "Cool"
}