{
    num: -3272,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Winter Power",
    pp: 10,
    priority: 0,
    flags: { protect: 1, failencore: 1, nosleeptalk: 1, noassist: 1, failcopycat: 1, failmimic: 1, failinstruct: 1, heal: 1 },
    drain: [1, 2],
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    onEffectiveness(typeMod, target, type, move) {
      return typeMod + this.dex.getEffectiveness("Ice", type);
    },
    secondary: null,
    target: "normal",
    type: "Grass",
    contestType: "Beautiful"
}