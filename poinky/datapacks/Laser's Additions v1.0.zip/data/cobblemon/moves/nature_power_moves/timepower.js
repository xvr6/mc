{
    num: -3275,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Time Power",
    pp: 10,
    priority: 0,
    flags: { protect: 1, failencore: 1, nosleeptalk: 1, noassist: 1, failcopycat: 1, failmimic: 1, failinstruct: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    onEffectiveness(typeMod, target, type, move) {
      return typeMod + this.dex.getEffectiveness("Ice", type);
    },
    secondary: {
      chance: 20,
      status: "frz"
    },
    target: "normal",
    type: "Psychic",
    contestType: "Beautiful"
}