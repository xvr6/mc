{
    num: -3262,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Storm Power",
    pp: 10,
    priority: 0,
    flags: { protect: 1, failencore: 1, nosleeptalk: 1, noassist: 1, failcopycat: 1, failmimic: 1, failinstruct: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    onEffectiveness(typeMod, target, type, move) {
      return typeMod + this.dex.getEffectiveness("Water", type);
    },
    secondary: {
      chance: 20,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Electric",
    contestType: "Beautiful"
}