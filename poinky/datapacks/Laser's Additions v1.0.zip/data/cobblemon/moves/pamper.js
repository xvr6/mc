{
    num: -3290,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Pamper",
    pp: 15,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.species.name === "Furfrou") {
        move.boosts = { def: 2, spe: 1 };
      } else if (pokemon.species.name === "Furfrou-Heart") {
        move.boosts = { spa: 2, spe: 1 };
      } else if (pokemon.species.name === "Furfrou-Star") {
        move.boosts = { spd: 2, spe: 1 };
      } else if (pokemon.species.name === "Furfrou-Diamond") {
        move.boosts = { def: 2, atk: 1 };
      } else if (pokemon.species.name === "Furfrou-Debutante") {
        move.boosts = { spe: 2, spa: 1 };
      } else if (pokemon.species.name === "Furfrou-Matron") {
        move.boosts = { spa: 2, spd: 1 };
      } else if (pokemon.species.name === "Furfrou-Dandy") {
        move.boosts = { spd: 2, def: 1 };
      } else if (pokemon.species.name === "Furfrou-La-Reine") {
        move.boosts = { spa: 2, def: 1 };
      } else if (pokemon.species.name === "Furfrou-Kabuki") {
        move.boosts = { atk: 2, def: 1 };
      } else if (pokemon.species.name === "Furfrou-Pharaoh") {
        move.boosts = { def: 2, spd: 1 };
      } else if (pokemon.species.name === "Furfrou-Matcha") {
        move.boosts = { atk: 2, spd: 1 };
      } else if (pokemon.species.name === "Furfrou-Lavender") {
        move.boosts = { spd: 2, spa: 1 };
      } else if (pokemon.species.name === "Furfrou-Cinnamon") {
        move.boosts = { def: 2, spa: 1 };
      } else if (pokemon.species.name === "Furfrou-Crusader") {
        move.boosts = { spe: 2, def: 1 };
      } else if (pokemon.species.name === "Furfrou-Rocker") {
        move.boosts = { atk: 2, spe: 1 };
      } else if (pokemon.species.name === "Furfrou-Mourner") {
        move.boosts = { atk: 2, spa: 1 };
      }
    },
    boosts: {
      atk: 1,
      spe: 1
    },
    secondary: null,
    target: "self",
    type: "Normal",
    zMove: { effect: "clearnegativeboost" },
    contestType: "Cute"
}