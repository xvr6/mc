{
    num: -3329,
    accuracy: 100,
    basePower: 60,
    basePowerCallback(pokemon, target, move) {
      if (!pokemon.volatiles["slickslime"]?.layers)
        return move.basePower;
      return move.basePower + (pokemon.volatiles["slickslime"].layers * 15);
    },
    category: "Special",
    name: "Slime Ball",
    pp: 15,
    priority: 0,
    flags: { protect: 1, metronome: 1, bullet: 1 },
    onHit(target, source, move) {
      if (source.volatiles["slickslime"]) {
        this.boost({ spe: -1 }, target);
      }
    },
    secondary: null,
    target: "normal",
    type: "Poison",
    contestType: "Clever"
}