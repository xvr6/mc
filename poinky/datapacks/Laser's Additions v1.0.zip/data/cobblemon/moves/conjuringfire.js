{
    num: -3326,
    accuracy: 100,
    basePower: 55,
    category: "Special",
    name: "Conjuring Fire",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1 },
    basePowerCallback(pokemon, target, move) {
      if (pokemon.hasItem(["ironball","bignugget","lifeorb","thickclub"])) {
        return move.basePower * 2;
      } else if (pokemon.hasItem(["loadeddice"])) {
        return move.basePower = 20;
      }
      return move.basePower;
    },
    onModifyMove(move, pokemon, source) {
      if (pokemon.hasItem(["absorbbulb","bigroot","shellbell","cloversweet"])) {
        move.drain = [1, 2];
      } else if (pokemon.hasItem(["dragonfang","razorclaw","scopelens","leek","luckypunch","blackaugurite"])) {
        move.willCrit = true;
      } else if (pokemon.hasItem(["ejectbutton","ejectpack","shedshell","smokeball"])) {
        move.selfSwitch = true;
      } else if (pokemon.hasItem(["leftovers","luckyegg","soothebell","sweetapple","flowersweet"])) {
        move.heal = [1, 4];
      } else if (pokemon.hasItem(["lifeorb"])) {
        move.recoil = [33, 100];
      } else if (pokemon.hasItem(["loadeddice"])) {
        move.multihit = [2, 5];
      } else if (pokemon.hasItem(["mirrorherb","expshare"])) {
        move.stealsBoosts = true;
      } else if (pokemon.hasItem(["redcard"])) {
        move.forceSwitch = true;
      } else if (pokemon.hasItem(["protectivepads","punchingglove","galaricacuff"])) {
        move.overrideDefensiveStat = "def";
      } else if (pokemon.hasItem(["normalgem"])) {
        move.type = "Normal";
      } else if (pokemon.hasItem(["firegem"])) {
        move.type = "Fire";
      } else if (pokemon.hasItem(["grassgem"])) {
        move.type = "Grass";
      } else if (pokemon.hasItem(["watergem"])) {
        move.type = "Water";
      } else if (pokemon.hasItem(["icegem"])) {
        move.type = "Ice";
      } else if (pokemon.hasItem(["electricgem"])) {
        move.type = "Electric";
      } else if (pokemon.hasItem(["psychicgem"])) {
        move.type = "Psychic";
      } else if (pokemon.hasItem(["darkgem"])) {
        move.type = "Dark";
      } else if (pokemon.hasItem(["fairygem"])) {
        move.type = "Fairy";
      } else if (pokemon.hasItem(["ghostgem"])) {
        move.type = "Ghost";
      } else if (pokemon.hasItem(["fightinggem"])) {
        move.type = "Fighting";
      } else if (pokemon.hasItem(["buggem"])) {
        move.type = "Bug";
      } else if (pokemon.hasItem(["flyinggem"])) {
        move.type = "Flying";
      } else if (pokemon.hasItem(["dragongem"])) {
        move.type = "Dragon";
      } else if (pokemon.hasItem(["rockgem"])) {
        move.type = "Rock";
      } else if (pokemon.hasItem(["groundgem"])) {
        move.type = "Ground";
      } else if (pokemon.hasItem(["steelgem"])) {
        move.type = "Steel";
      } else if (pokemon.hasItem(["poisongem"])) {
        move.type = "Poison";
      }
    },
    onModifyPriority(priority, pokemon, target, move) {
      if (pokemon.hasItem(["quickclaw","sharpbeak"]))
        return priority + 1;
    },
    onHit(target, source, move) {
      if (source.hasItem(["airballoon"])) {
        source.addVolatile("magnetrise");
      } else if (source.hasItem(["assaultvest","eviolite","deepseascale"])) {
        this.boost({ spd: 1 }, source);
      } else if (source.hasItem(["blackbelt","choiceband","expertbelt","muscleband"])) {
        this.boost({ atk: 1 }, source);
      } else if (source.hasItem(["quickpowder","choicescarf","silkscarf"])) {
        this.boost({ spe: 1 }, source);
      } else if (source.hasItem(["roomservice"])) {
        this.boost({ spe: -1 }, source);
      } else if (source.hasItem(["choicespecs","deepseatooth","throatspray"])) {
        this.boost({ spa: 1 }, source);
      } else if (source.hasItem(["metalcoat","metalpowder","hardstone","protector","metalalloy","shellhelmet"])) {
        this.boost({ def: 1 }, source);
      } else if (source.hasItem(["widelens","zoomlens","syrupyapple"])) {
        this.boost({ accuracy: 1 }, source);
      } else if (source.hasItem(["weaknesspolicy","boosterenergy"])) {
        this.boost({ atk: 1, spa: 1 }, source);
      } else if (source.getItem().isBerry) {
        source.eatItem(true);
      } else if (source.hasItem(["cellbattery","magnet","upgrade","dubiousdisc"])) {
        source.addVolatile("charge");
      } else if (source.hasItem(["clearamulet","whiteherb","everstone","cleansetag"])) {
        target.clearBoosts();
        this.add("-clearboost", target);
      } else if (source.hasItem(["charcoal","flameorb","firestone","magmarizer"])) {
        target.trySetStatus("brn", source);
      } else if (source.hasItem(["lightball","thunderorb","thunderstone","electirizer"])) {
        target.trySetStatus("par", source);
      } else if (source.hasItem(["frostorb","icestone"])) {
        target.trySetStatus("frz", source);
      } else if (source.hasItem(["bindingband","gripclaw"])) {
        target.addVolatile("partiallytrapped", source, this.dex.getActiveMove("Fire Spin"));
      } else if (source.hasItem(["blackglasses","ringtarget"])) {
        target.addVolatile("taunt");
      } else if (source.hasItem(["blacksludge","poisonbarb"])) {
        target.trySetStatus("psn", source);
      } else if (source.hasItem(["toxicorb"])) {
        target.trySetStatus("tox", source);
      } else if (source.hasItem(["blunderpolicy","brightpowder","shinystone"])) {
        this.boost({ accuracy: -1 });
      } else if (source.hasItem(["abilityshield","duskstone"])) {
        target.addVolatile("gastroacid");
      } else if (source.hasItem(["covertcloak","spelltag","reapercloth"])) {
        target.addVolatile("foresight");
      } else if (source.hasItem(["destinyknot","fairyfeather","whippeddream","lovesweet"])) {
        target.addVolatile("attract");
      } else if (source.hasItem(["damprock"])) {
        this.field.setWeather("raindance");
      } else if (source.hasItem(["heatrock","sunstone"])) {
        this.field.setWeather("sunnyday");
      } else if (source.hasItem(["icyrock","snowball"])) {
        this.field.setWeather("snow");
      } else if (source.hasItem(["nevermeltice"])) {
        this.field.setWeather("hail");
      } else if (source.hasItem(["smoothrock","softsand"])) {
        this.field.setWeather("sandstorm");
      } else if (source.hasItem(["utilityumbrella","safetygoggles"])) {
        this.field.clearWeather();
      } else if (source.hasItem(["terrainextender"])) {
        this.field.clearTerrain();
      } else if (source.hasItem(["electricseed"])) {
        this.field.setTerrain("electricterrain");
      } else if (source.hasItem(["grassyseed"])) {
        this.field.setTerrain("grassyterrain");
      } else if (source.hasItem(["psychicseed"])) {
        this.field.setTerrain("psychicterrain");
      } else if (source.hasItem(["mistyseed","sachet"])) {
        this.field.setTerrain("mistyterrain");
      } else if (source.hasItem(["twistedspoon","silverpowder","dawnstone","flowersweet"])) {
        target.addVolatile("confusion");
      } else if (source.hasItem(["focussash","focusband","powerherb"])) {
        source.addVolatile("focusenergy");
      } else if (source.hasItem(["floatstone","moonstone"])) {
        target.addVolatile("telekinesis");
      } else if (source.hasItem(["mentalherb","metronome","galaricawreath","ribbonsweet"])) {
        target.addVolatile("encore");
      } else if (source.hasItem(["rockyhelmet","heavydutyboots","stickybarb"])) {
        const side = target.isAlly(source) ? target.side.foe : target.side;
        const spikes = side.sideConditions["spikes"];
        if ((!spikes || spikes.layers < 2)) {
          side.addSideCondition("spikes", target);
        }
      } else if (source.hasItem(["lightclay","peatblock","prismscale"])) {
        const side = source.isAlly(target) ? source.side.foe : source.side;
        const screens = side.sideConditions["auroraveil"];
        if ((!screens)) {
          side.addSideCondition("auroraveil", source);
        }
      } else if (source.hasItem(["ironball","laggingtail","poweranklet","powerband","powerbelt","powerbracer","powerlens","powerweight"])) {
        this.boost({ spe: -1 }, source);
      } else if (source.hasItem(["adrenalineorb","maliciousarmor"])) {
        this.boost({ atk: -1 }, target);
      } else if (source.hasItem(["crackedpot","unremarkableteacup","auspiciousarmor"])) {
        this.boost({ def: -1 }, target);
      } else if (source.hasItem(["kingsrock","razorfang","dragonscale","tartapple","chippedpot","masterpieceteacup"])) {
        target.addVolatile("flinch");
      } else if (source.hasItem(["miracleseed","luminousmoss","leafstone"])) {
        source.addVolatile("ingrain");
      } else if (source.hasItem(["mysticwater","waterstone","berrysweet"])) {
        source.addVolatile("aquaring");
      }
    },
    onAfterHit(target, source, move) {
      if (source.item && source.hp) {
        const item = source.getItem();
        source.setItem("");
        source.lastItem = item.id;
        source.usedItemThisTurn = true;
        this.add("-enditem", source, item.name, "[from] move: Conjuring Fire");
        this.runEvent("AfterUseItem", source, null, null, item);
      }
    },
    onAfterSubDamage(damage, target, source, move) {
      if (source.item && source.hp) {
        const item = source.getItem();
        source.setItem("");
        source.lastItem = item.id;
        source.usedItemThisTurn = true;
        this.add("-enditem", source, item.name, "[from] move: Conjuring Fire");
        this.runEvent("AfterUseItem", source, null, null, item);
      }
    },
    secondary: null,
    target: "normal",
    type: "Fire",
    contestType: "Clever"
}