{
    num: -3302,
    accuracy: 80,
    basePower: 20,
    basePowerCallback(pokemon, target, move) {
      return 20 * move.hit;
    },
    category: "Physical",
    name: "Triple Tumble",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    multihit: 3,
    multiaccuracy: true,
    secondary: null,
    self: {
      onHit(source) {
        const result = this.random(3);
        if (result === 0) {
          this.boost({ atk: -1 }, source);
        } else if (result === 1) {
          this.boost({ def: -1 }, source);
        } else {
          this.boost({ spe: -1 }, source);
        }
      }
    },
    target: "normal",
    type: "Normal",
    zMove: { basePower: 120 },
    maxMove: { basePower: 140 }
}