{
    num: -3240,
    accuracy: 100,
    basePower: 70,
    category: "Physical",
    name: "Thunder Claw",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Electric",
    contestType: "Cool"
}