{
    num: -3289,
    accuracy: 100,
    basePower: 85,
    category: "Physical",
    name: "Guard Coat",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1 },
    overrideOffensiveStat: "def",
    secondary: {
      chance: 30,
      onHit(target, source, move) {
        if (source.species.name === "Furfrou-Heart") {
          target.addVolatile("attract", source, move);
        } else if (source.species.name === "Furfrou-Star") {
          target.addVolatile("confusion", source, move);
        } else if (source.species.name === "Furfrou-Diamond") {
          this.boost({ def: -1 });
        } else if (source.species.name === "Furfrou-Debutante") {
          target.setStatus("par", source, move);
        } else if (source.species.name === "Furfrou-Matron") {
          this.boost({ spa: -1 });
        } else if (source.species.name === "Furfrou-Dandy") {
          this.boost({ spd: -1 });
        } else if (source.species.name === "Furfrou-La-Reine") {
          source.addVolatile("aquaring");
        } else if (source.species.name === "Furfrou-Kabuki") {
          this.boost({ atk: -1 });
        } else if (source.species.name === "Furfrou-Pharaoh") {
          this.boost({ spe: -1 });
        } else if (source.species.name === "Furfrou-Matcha") {
          target.addVolatile("leechseed", source, move);
        } else if (source.species.name === "Furfrou-Lavender") {
          target.addVolatile("healblock", source, move);
        } else if (source.species.name === "Furfrou-Cinnamon") {
          this.boost({ evasion: -1 });
        } else if (source.species.name === "Furfrou-Crusader") {
          target.addVolatile("trapped", source, move, "trapper");
        } else if (source.species.name === "Furfrou-Rocker") {
          target.addVolatile("throatchop", source, move);
        } else if (source.species.name === "Furfrou-Mourner") {
          target.addVolatile("gastroacid", source, move);
        } else {
          target.addVolatile("flinch", source, move);
        }
      }
    },
    target: "normal",
    type: "Normal"
}