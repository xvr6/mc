{
    num: 918,
    accuracy: 100,
    basePower: 60,
    category: "Physical",
    name: "Upper Hand",
    pp: 10,
    priority: 4,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    onTryHit(target, pokemon) {
      const action = this.queue.willMove(target);
      const move = action?.choice === "move" ? action.move : null;
      if (!move || move.priority <= 0.1 || move.category === "Status") {
        return false;
      }
    },
    secondary: {
      chance: 100,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Fighting"
}