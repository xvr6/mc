{
    num: 324,
    accuracy: 100,
    basePower: 75,
    category: "Special",
    isNonstandard: "Past",
    name: "Signal Beam",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, light: 1, beam: 1 },
    secondary: {
      chance: 20,
      volatileStatus: "confusion"
    },
    target: "normal",
    type: "Bug",
    contestType: "Beautiful"
}