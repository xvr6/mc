{
    num: 907,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Fickle Beam",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, beam: 1, light: 1 },
    onBasePower(basePower, pokemon) {
      if (this.randomChance(3, 10)) {
        this.attrLastMove("[anim] Fickle Beam All Out");
        this.add("-activate", pokemon, "move: Fickle Beam");
        return this.chainModify(2);
      }
    },
    secondary: null,
    target: "normal",
    type: "Dragon"
}