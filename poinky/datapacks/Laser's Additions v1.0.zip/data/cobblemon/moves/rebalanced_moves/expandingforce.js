{
    num: 797,
    accuracy: 100,
    basePower: 75,
    category: "Special",
    name: "Expanding Force",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onBasePower(basePower, source) {
      if (this.field.isTerrain("psychicterrain") && source.isGrounded()) {
        this.debug("terrain buff");
        return this.chainModify(1.5);
      }
    },
    onModifyMove(move, source, target) {
      if (this.field.isTerrain("psychicterrain") && source.isGrounded()) {
        move.target = "allAdjacentFoes";
      }
    },
    secondary: null,
    target: "normal",
    type: "Psychic"
}