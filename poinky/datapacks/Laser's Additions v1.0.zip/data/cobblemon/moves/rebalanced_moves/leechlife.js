{
    num: 141,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "Leech Life",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, heal: 1, metronome: 1, bite: 1 },
    drain: [1, 2],
    secondary: null,
    target: "normal",
    type: "Bug",
    contestType: "Clever"
}