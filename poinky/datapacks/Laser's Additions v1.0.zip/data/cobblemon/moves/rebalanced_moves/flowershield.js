{
    num: 579,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Flower Shield",
    pp: 10,
    priority: 0,
    flags: { distance: 1, metronome: 1 },
    onHitSide(side, source, move) {
      const targets = side.allies().filter((target) => target.hasType(["Grass", "Fairy"]) && (!target.volatiles["maxguard"] || this.runEvent("TryHit", target, source, move)));
      if (!targets.length)
        return false;
      let didSomething = false;
      for (const target of targets) {
        didSomething = this.boost({ def: 1, spd: 1 }, target, source, move, false, true) || didSomething;
      }
      return didSomething;
    },
    secondary: null,
    target: "allySide",
    type: "Fairy",
    zMove: { boost: { def: 1 } },
    contestType: "Beautiful"
}