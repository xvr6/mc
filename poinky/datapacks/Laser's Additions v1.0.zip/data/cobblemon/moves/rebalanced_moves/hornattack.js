{
    num: 30,
    accuracy: true,
    basePower: 70,
    category: "Physical",
    name: "Horn Attack",
    pp: 25,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cool"
}