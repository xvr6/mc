{
    num: 454,
    accuracy: 100,
    basePower: 90,
    category: "Physical",
    name: "Attack Order",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onModifyMove(move, pokemon) {
      for (const allyActive of pokemon.allies()) {
        if (allyActive.hasType("Bug")) {
          move.multihit = 2;
          move.multihitType = "parentalbond";
        }
      }
      if (pokemon.hp <= pokemon.maxhp / 3 && pokemon.hasAbility("swarm")) {
        move.willCrit = true;
      }
    },
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Bug",
    contestType: "Clever"
}