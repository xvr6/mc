{
    num: 571,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Forest's Curse",
    pp: 20,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, allyanim: 1, metronome: 1 },
    onHit(target) {
      if (target.hasType("Grass"))
        return false;
      if (!target.addType("Grass"))
        return false;
      this.add("-start", target, "typeadd", "Grass", "[from] move: Forest's Curse");
    },
    secondary: {
      chance: 100,
      onHit(target, source, move) {
        if (source.isActive)
          target.addVolatile("trapped", source, move, "trapper");
      }
    },
    target: "normal",
    type: "Grass",
    zMove: { boost: { atk: 1, def: 1, spa: 1, spd: 1, spe: 1 } },
    contestType: "Clever"
}