{
    num: 230,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Sweet Scent",
    pp: 20,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1 },
    self: {
      volatileStatus: "honeygather"
    },
    boosts: {
      evasion: -2
    },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Normal",
    zMove: { boost: { accuracy: 1 } },
    contestType: "Cute"
}