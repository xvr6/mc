{
    num: 537,
    accuracy: 100,
    basePower: 65,
    category: "Physical",
    isNonstandard: "Past",
    name: "Steamroller",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondaries: [
      {
        chance: 30,
        volatileStatus: "flinch"
      },
      {
        chance: 100,
        self: {
          boosts: {
            spe: 1
          }
        }
      }
    ],
    target: "normal",
    type: "Bug",
    contestType: "Tough"
}