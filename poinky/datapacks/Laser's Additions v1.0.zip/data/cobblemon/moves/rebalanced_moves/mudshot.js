{
    num: 341,
    accuracy: 95,
    basePower: 55,
    category: "Special",
    name: "Mud Shot",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: {
      chance: 100,
      boosts: {
        spe: -1
      }
    },
    target: "allAdjacentFoes",
    type: "Ground",
    contestType: "Tough"
}