{
    num: 255,
    accuracy: 100,
    basePower: 0,
    basePowerCallback(pokemon) {
      if (!pokemon.volatiles["stockpile"]?.layers)
        return false;
      return pokemon.volatiles["stockpile"].layers * 100;
    },
    category: "Special",
    name: "Spit Up",
    pp: 10,
    priority: 0,
    flags: { protect: 1, metronome: 1 },
    onTry(source) {
      return !!source.volatiles["stockpile"];
    },
    onAfterMove(pokemon) {
      pokemon.removeVolatile("stockpile");
    },
    secondary: null,
    target: "normal",
    type: "Poison",
    contestType: "Tough"
}