{
    num: 66,
    accuracy: 100,
    basePower: 90,
    category: "Physical",
    isNonstandard: "Past",
    name: "Submission",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, throwing: 1 },
    recoil: [1, 4],
    secondary: null,
    target: "normal",
    type: "Fighting",
    contestType: "Cool"
}