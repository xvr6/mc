{
    num: 572,
    accuracy: 90,
    basePower: 95,
    category: "Special",
    name: "Petal Blizzard",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, wind: 1 },
    secondary: {
      chance: 10,
      boosts: {
        spd: -1
      }
    },
    target: "allAdjacentFoes",
    type: "Grass",
    contestType: "Beautiful"
}