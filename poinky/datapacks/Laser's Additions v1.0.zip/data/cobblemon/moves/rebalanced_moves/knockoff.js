{
    num: 282,
    accuracy: 100,
    basePower: 55,
    category: "Physical",
    name: "Knock Off",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    basePowerCallback(pokemon, target, move) {
      const item = target.getItem();
      if (!this.singleEvent("TakeItem", item, target.itemState, target, target, move, item))
        return move.basePower;
      if (item.id && !target.hasAbility(["stickyhold","suctioncups"])) {
        return move.basePower * 1.5;
      }
      return move.basePower;
    },
    onAfterHit(target, source) {
      if (source.hp) {
        const item = target.takeItem();
        if (item) {
          this.add("-enditem", target, item.name, "[from] move: Knock Off", "[of] " + source);
        }
      }
    },
    secondary: null,
    target: "normal",
    type: "Dark",
    contestType: "Clever"
}