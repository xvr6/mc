{
    num: 121,
    accuracy: 95,
    basePower: 100,
    category: "Physical",
    isNonstandard: "Past",
    name: "Egg Bomb",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cute"
}