{
    num: 134,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Kinesis",
    pp: 20,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    boosts: {
      spa: 1,
      def: 1
    },
    secondary: null,
    target: "self",
    type: "Psychic",
    zMove: { boost: { def: 1 } },
    contestType: "Clever"
}