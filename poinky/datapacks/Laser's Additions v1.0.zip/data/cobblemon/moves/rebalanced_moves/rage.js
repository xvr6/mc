{
    num: 99,
    accuracy: 100,
    basePower: 25,
    basePowerCallback(pokemon) {
      return Math.min(200, 25 + 25 * pokemon.timesAttacked);
    },
    category: "Physical",
    isNonstandard: "Past",
    name: "Rage",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Tough"
}