{
    num: 27,
    accuracy: 100,
    basePower: 60,
    category: "Physical",
    isNonstandard: "Past",
    name: "Rolling Kick",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, kick: 1 },
    secondary: {
      chance: 30,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Fighting",
    contestType: "Cool"
}