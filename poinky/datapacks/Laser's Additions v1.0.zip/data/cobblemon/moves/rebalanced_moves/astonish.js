{
    num: 310,
    accuracy: 100,
    basePower: 30,
    category: "Physical",
    name: "Astonish",
    pp: 10,
    priority: 1,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    onTry(source) {
      if (source.activeMoveActions > 1) {
        this.hint("Astonish only works on your first turn out.");
        return false;
      }
    },
    secondary: {
      chance: 100,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Ghost",
    contestType: "Cute"
}