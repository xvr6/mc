{
    num: 509,
    accuracy: 90,
    basePower: 60,
    category: "Physical",
    name: "Circle Throw",
    pp: 10,
    priority: -6,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, noassist: 1, failcopycat: 1, throwing: 1 },
    forceSwitch: true,
    target: "normal",
    type: "Fighting",
    contestType: "Cool"
}