{
    num: 61,
    accuracy: 100,
    basePower: 65,
    category: "Special",
    name: "Bubble Beam",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, beam: 1 },
    secondary: {
      chance: 30,
      boosts: {
        spe: -1
      }
    },
    target: "normal",
    type: "Water",
    contestType: "Beautiful"
}