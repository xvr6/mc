{
    num: 129,
    accuracy: true,
    basePower: 60,
    category: "Special",
    name: "Swift",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, light: 1 },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Normal",
    contestType: "Cool"
}