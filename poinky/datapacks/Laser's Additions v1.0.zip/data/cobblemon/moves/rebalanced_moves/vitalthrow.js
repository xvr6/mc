{
    num: 233,
    accuracy: 100,
    basePower: 60,
    basePowerCallback(pokemon, target, move) {
      const damagedByTarget = pokemon.attackedBy.some(
        (p) => p.source === target && p.damage > 0 && p.thisTurn
      );
      if (damagedByTarget) {
        this.debug("BP doubled for getting hit by " + target);
        return move.basePower * 2;
      }
      return move.basePower;
    },
    category: "Physical",
    name: "Vital Throw",
    pp: 10,
    priority: -4,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, throwing: 1 },
    secondary: null,
    target: "normal",
    type: "Fighting",
    contestType: "Cool"
}