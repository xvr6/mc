{
    num: 159,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Sharpen",
    pp: 20,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    boosts: {
      atk: 1,
      spe: 1
    },
    secondary: null,
    target: "self",
    type: "Normal",
    zMove: { boost: { atk: 1 } },
    contestType: "Cute"
}