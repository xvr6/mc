{
    num: 190,
    accuracy: 85,
    basePower: 85,
    category: "Special",
    isNonstandard: "Past",
    name: "Octazooka",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: {
      chance: 100,
      boosts: {
        accuracy: -1
      }
    },
    target: "normal",
    type: "Water",
    contestType: "Tough"
}