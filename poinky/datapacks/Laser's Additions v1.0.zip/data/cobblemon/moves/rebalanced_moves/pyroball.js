{
    num: 780,
    accuracy: 85,
    basePower: 120,
    category: "Physical",
    name: "Pyro Ball",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, defrost: 1, bullet: 1, kick: 1 },
    secondary: {
      chance: 10,
      status: "brn"
    },
    target: "normal",
    type: "Fire"
}