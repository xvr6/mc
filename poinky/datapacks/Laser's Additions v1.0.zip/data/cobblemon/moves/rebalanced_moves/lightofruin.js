{
    num: 617,
    accuracy: 90,
    basePower: 140,
    category: "Special",
    isNonstandard: "Past",
    name: "Light of Ruin",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, light: 1, beam: 1 },
    recoil: [1, 2],
    secondary: null,
    target: "normal",
    type: "Fairy",
    contestType: "Beautiful"
}