{
    num: 570,
    accuracy: 100,
    basePower: 75,
    category: "Special",
    name: "Parabolic Charge",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, heal: 1, metronome: 1, light: 1 },
    drain: [1, 2],
    secondary: null,
    target: "allAdjacent",
    type: "Electric",
    contestType: "Clever"
}