{
    num: 563,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Rototiller",
    pp: 10,
    priority: 0,
    flags: { distance: 1, nonsky: 1, metronome: 1 },
    onHitSide(side, source, move) {
      const targets = side.allies().filter((target) => target.hasType(["Grass", "Ground"]) && target.runImmunity("Ground") && (!target.volatiles["maxguard"] || this.runEvent("TryHit", target, source, move)));
      if (!targets.length)
        return false;
      let didSomething = false;
      for (const target of targets) {
        didSomething = this.boost({ atk: 1, spa: 1 }, target, source, move, false, true) || didSomething;
      }
      return didSomething;
    },
    secondary: null,
    target: "allySide",
    type: "Ground",
    zMove: { boost: { atk: 1 } },
    contestType: "Tough"
}