{
    num: 342,
    accuracy: 100,
    basePower: 60,
    category: "Physical",
    name: "Poison Tail",
    pp: 25,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    critRatio: 2,
    secondary: {
      chance: 30,
      status: "psn"
    },
    target: "normal",
    type: "Poison",
    contestType: "Clever"
}