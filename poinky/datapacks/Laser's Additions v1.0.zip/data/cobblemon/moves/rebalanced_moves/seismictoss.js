{
    num: 69,
    accuracy: 100,
    basePower: 0,
    damage: "level",
    category: "Physical",
    name: "Seismic Toss",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, nonsky: 1, metronome: 1, throwing: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.hasAbility("strongarm")) {
        move.damage = pokemon.level * 1.5;
      }
    },
    secondary: null,
    target: "normal",
    type: "Fighting",
    maxMove: { basePower: 75 },
    contestType: "Tough"
}