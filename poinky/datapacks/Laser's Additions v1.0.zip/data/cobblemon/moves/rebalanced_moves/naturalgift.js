{
    num: 363,
    accuracy: 100,
    basePower: 0,
    category: "Physical",
    isNonstandard: "Past",
    name: "Natural Gift",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onModifyType(move, pokemon) {
      if (pokemon.ignoringItem())
        return;
      const item = pokemon.getItem();
      if (!item.naturalGift)
        return;
      move.type = item.naturalGift.type;
    },
    onPrepareHit(target, pokemon, move) {
      if (pokemon.ignoringItem())
        return false;
      const item = pokemon.getItem();
      if (!item.naturalGift)
        return false;
      move.basePower = item.naturalGift.basePower;
      this.debug("BP: " + move.basePower);
      pokemon.setItem("");
      pokemon.lastItem = item.id;
      pokemon.usedItemThisTurn = true;
      this.runEvent("AfterUseItem", pokemon, null, null, item);
    },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) < pokemon.getStat("spa", false, true))
        move.category = "Special";
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    zMove: { basePower: 160 },
    maxMove: { basePower: 130 },
    contestType: "Clever"
}