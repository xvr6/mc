{
    num: 72,
    accuracy: 100,
    basePower: 60,
    category: "Special",
    name: "Mega Drain",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, heal: 1, metronome: 1 },
    drain: [1, 2],
    secondary: null,
    target: "normal",
    type: "Grass",
    zMove: { basePower: 120 },
    contestType: "Clever"
}