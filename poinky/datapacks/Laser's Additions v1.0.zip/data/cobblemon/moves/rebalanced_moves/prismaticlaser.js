{
    num: 711,
    accuracy: 100,
    basePower: 160,
    category: "Special",
    name: "Prismatic Laser",
    pp: 10,
    priority: 0,
    flags: { recharge: 1, protect: 1, mirror: 1, metronome: 1, beam: 1, light: 1 },
    self: {
      volatileStatus: "mustrecharge"
    },
    secondary: null,
    target: "normal",
    type: "Psychic",
    contestType: "Cool"
}