{
  num: 567,
  accuracy: 100,
  basePower: 0,
  category: "Status",
  isNonstandard: "Past",
  name: "Trick-or-Treat",
  pp: 20,
  priority: 0,
  flags: { protect: 1, reflectable: 1, mirror: 1, allyanim: 1, metronome: 1 },
  onHit(target) {
    if (target.hasType("Ghost"))
      return false;
    if (!target.addType("Ghost"))
      return false;
    this.add("-start", target, "typeadd", "Ghost", "[from] move: Trick-or-Treat");
    if (target.side.active.length === 2 && target.position === 1) {
      const action = this.queue.willMove(target);
      if (action && action.move.id === "curse") {
        action.targetLoc = -1;
      }
    }
  },
  secondary: {
    chance: 100,
    onHit(target, source, move) {
      if (source.isActive)
        target.addVolatile("trapped", source, move, "trapper");
    }
  },
  target: "normal",
  type: "Ghost",
  zMove: { boost: { atk: 1, def: 1, spa: 1, spd: 1, spe: 1 } },
  contestType: "Cute"
}