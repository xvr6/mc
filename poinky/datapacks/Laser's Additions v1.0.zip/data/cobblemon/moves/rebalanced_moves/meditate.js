{
    num: 96,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Meditate",
    pp: 20,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    boosts: {
      atk: 1,
      spd: 1
    },
    secondary: null,
    target: "self",
    type: "Psychic",
    zMove: { boost: { atk: 1 } },
    contestType: "Beautiful"
}