{
    num: 754,
    accuracy: 100,
    basePower: 55,
    basePowerCallback(pokemon, target, move) {
      if (target.newlySwitched || this.queue.willMove(target)) {
        this.debug("Bolt Beak damage boost");
        return move.basePower * 2;
      }
      this.debug("Bolt Beak NOT boosted");
      return move.basePower;
    },
    category: "Physical",
    isNonstandard: "Past",
    name: "Bolt Beak",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "normal",
    type: "Electric"
}