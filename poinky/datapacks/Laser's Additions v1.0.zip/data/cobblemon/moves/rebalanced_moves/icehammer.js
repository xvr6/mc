{
    num: 665,
    accuracy: 95,
    basePower: 100,
    category: "Physical",
    name: "Ice Hammer",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, punch: 1, metronome: 1, hammer: 1 },
    self: {
      boosts: {
        spe: -1
      }
    },
    secondary: null,
    target: "normal",
    type: "Ice",
    contestType: "Tough"
}