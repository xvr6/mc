{
    num: 485,
    accuracy: 100,
    basePower: 120,
    category: "Special",
    isNonstandard: "Past",
    name: "Synchronoise",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onTryImmunity(target, source) {
      return target.hasType(source.getTypes());
    },
    onEffectiveness(typeMod, target, type, move) {
      return typeMod - this.dex.getEffectiveness("Psychic", type);
    },
    ignoreImmunity: true,
    secondary: null,
    target: "allAdjacent",
    type: "Psychic",
    contestType: "Clever"
}