{
    num: 546,
    accuracy: 100,
    basePower: 120,
    category: "Special",
    isNonstandard: "Past",
    name: "Techno Blast",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, light: 1, beam: 1 },
    onModifyType(move, pokemon) {
      if (pokemon.ignoringItem())
        return;
      move.type = this.runEvent("Drive", pokemon, null, move, "Normal");
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cool"
}