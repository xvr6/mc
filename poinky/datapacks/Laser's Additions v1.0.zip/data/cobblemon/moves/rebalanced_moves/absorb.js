{
    num: 71,
    accuracy: 100,
    basePower: 40,
    category: "Special",
    name: "Absorb",
    pp: 25,
    priority: 0,
    flags: { protect: 1, mirror: 1, heal: 1, metronome: 1 },
    drain: [3, 4],
    secondary: null,
    target: "normal",
    type: "Grass",
    contestType: "Clever"
}