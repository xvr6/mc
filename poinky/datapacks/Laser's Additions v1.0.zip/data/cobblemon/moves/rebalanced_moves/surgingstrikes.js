{
    num: 818,
    accuracy: 100,
    basePower: 20,
    category: "Physical",
    name: "Surging Strikes",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, punch: 1, kick: 1 },
    willCrit: true,
    multihit: 3,
    secondary: null,
    target: "normal",
    type: "Water",
    zMove: { basePower: 130 },
    maxMove: { basePower: 120 }
}