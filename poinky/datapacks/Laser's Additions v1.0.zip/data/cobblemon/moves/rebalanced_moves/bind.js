{
    num: 20,
    accuracy: 85,
    basePower: 35,
    category: "Physical",
    name: "Bind",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    volatileStatus: "partiallytrapped",
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Tough"
}