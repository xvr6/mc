{
    num: 24,
    accuracy: 100,
    basePower: 30,
    category: "Physical",
    name: "Double Kick",
    pp: 30,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, kick: 1 },
    multihit: 2,
    secondary: null,
    target: "normal",
    type: "Fighting",
    maxMove: { basePower: 80 },
    contestType: "Cool"
}