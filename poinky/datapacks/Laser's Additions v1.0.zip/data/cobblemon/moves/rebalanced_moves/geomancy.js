{
    num: 601,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Geomancy",
    pp: 10,
    priority: 0,
    flags: { charge: 1, nonsky: 1, metronome: 1, nosleeptalk: 1, failinstruct: 1 },
    onTryMove(attacker, defender, move) {
      if (attacker.removeVolatile(move.id)) {
        return;
      }
      this.add("-prepare", attacker, move.name);
      if (!this.runEvent("ChargeMove", attacker, defender, move)) {
        return;
      }
      attacker.addVolatile("twoturnmove", defender);
      return null;
    },
    onHit(target) {
      if (target.usedItemThisTurn) {
        this.boost({ spa: 1, spd: 1, spe: 1 }, target);
      } else {
        this.boost({ spa: 2, spd: 2, spe: 2 }, target);
      }
    },
    secondary: null,
    target: "self",
    type: "Fairy",
    zMove: { boost: { atk: 1, def: 1, spa: 1, spd: 1, spe: 1 } },
    contestType: "Beautiful"
}