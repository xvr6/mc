{
    num: 795,
    accuracy: 90,
    basePower: 160,
    category: "Special",
    isNonstandard: "Past",
    name: "Eternabeam",
    pp: 5,
    priority: 0,
    flags: { recharge: 1, protect: 1, mirror: 1, beam: 1 },
    self: {
      volatileStatus: "mustrecharge"
    },
    secondary: null,
    target: "normal",
    type: "Dragon"
}