{
    num: 888,
    accuracy: 100,
    basePower: 40,
    category: "Special",
    name: "Twin Beam",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, beam: 1, noparentalbond: 1 },
    multihit: 2,
    smartTarget: true,
    secondary: null,
    target: "normal",
    type: "Psychic",
    maxMove: { basePower: 120 },
    contestType: "Cool"
}