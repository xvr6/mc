{
    num: 598,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Eerie Impulse",
    pp: 15,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1, light: 1 },
    boosts: {
      spa: -2
    },
    secondary: null,
    target: "normal",
    type: "Electric",
    zMove: { boost: { spd: 1 } },
    contestType: "Clever"
}