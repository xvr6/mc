{
    num: 549,
    accuracy: 95,
    basePower: 75,
    category: "Special",
    name: "Glaciate",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, wind: 1 },
    secondary: {
      chance: 100,
      boosts: {
        spe: -1
      }
    },
    target: "allAdjacentFoes",
    type: "Ice",
    contestType: "Beautiful"
  }