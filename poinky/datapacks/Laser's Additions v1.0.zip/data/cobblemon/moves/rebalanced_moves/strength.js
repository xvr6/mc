{
    num: 70,
    accuracy: 90,
    basePower: 90,
    category: "Physical",
    name: "Strength",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, punch: 1 },
    secondary: {
      chance: 30,
      self: {
        boosts: {
          atk: 1
        }
      }
    },
    target: "normal",
    type: "Normal",
    contestType: "Tough"
}