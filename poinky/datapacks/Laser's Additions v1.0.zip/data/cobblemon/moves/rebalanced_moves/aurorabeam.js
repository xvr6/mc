{
    num: 62,
    accuracy: 100,
    basePower: 65,
    category: "Special",
    name: "Aurora Beam",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, light: 1, beam: 1 },
    secondary: {
      chance: 30,
      boosts: {
        atk: -1
      }
    },
    target: "normal",
    type: "Ice",
    contestType: "Beautiful"
}