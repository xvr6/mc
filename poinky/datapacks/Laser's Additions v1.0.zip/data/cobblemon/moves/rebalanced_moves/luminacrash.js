{
    num: 855,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Lumina Crash",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, light: 1 },
    secondary: {
      chance: 100,
      boosts: {
        spd: -2
      }
    },
    target: "normal",
    type: "Psychic"
}