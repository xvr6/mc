{
    num: 82,
    accuracy: 100,
    basePower: 0,
    damage: "level",
    category: "Special",
    isNonstandard: "Past",
    name: "Dragon Rage",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "normal",
    type: "Dragon",
    contestType: "Cool"
}