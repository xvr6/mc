{
    num: 872,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "Aqua Step",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, dance: 1, metronome: 1, kick: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: 1
        }
      }
    },
    target: "normal",
    type: "Water",
    contestType: "Cool"
}