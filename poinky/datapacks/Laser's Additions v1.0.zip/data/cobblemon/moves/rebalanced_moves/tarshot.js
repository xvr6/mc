{
    num: 749,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Tar Shot",
    pp: 15,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1 },
    volatileStatus: "tarshot",
    condition: {
      onStart(pokemon) {
        if (pokemon.terastallized)
          return false;
        this.add("-start", pokemon, "Tar Shot");
      },
      onEffectivenessPriority: -2,
      onEffectiveness(typeMod, target, type, move) {
        if (move.type !== "Fire")
          return;
        if (!target)
          return;
        if (type !== target.getTypes()[0])
          return;
        return typeMod + 1;
      }
    },
    boosts: {
      spe: -1
    },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Rock"
}