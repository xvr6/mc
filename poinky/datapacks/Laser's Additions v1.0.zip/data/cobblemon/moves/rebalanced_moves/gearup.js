{
    num: 674,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Gear Up",
    pp: 10,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    boosts: {
      spe: 2,
      spa: 1
    },
    secondary: null,
    target: "self",
    type: "Steel",
    zMove: { effect: "clearnegativeboost" },
    contestType: "Clever"
}