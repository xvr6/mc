{
    num: 412,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Energy Ball",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: {
      chance: 20,
      boosts: {
        spd: -1
      }
    },
    target: "normal",
    type: "Grass",
    contestType: "Beautiful"
}