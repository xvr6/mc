{
    num: 753,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Octolock",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, throwing: 1 },
    onTryImmunity(target) {
      return this.dex.getImmunity("trapped", target);
    },
    volatileStatus: "octolock",
    condition: {
      onStart(pokemon, source) {
        this.add("-start", pokemon, "move: Octolock", "[of] " + source);
      },
      onResidualOrder: 14,
      onResidual(pokemon) {
        const source = this.effectState.source;
        if (source && (!source.isActive || source.hp <= 0 || !source.activeTurns)) {
          delete pokemon.volatiles["octolock"];
          this.add("-end", pokemon, "Octolock", "[partiallytrapped]", "[silent]");
          return;
        }
        this.boost({ def: -1, spd: -1 }, pokemon, source, this.dex.getActiveMove("octolock"));
      },
      onTrapPokemon(pokemon) {
        if (this.effectState.source && this.effectState.source.isActive)
          pokemon.tryTrap();
      }
    },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          def: 2
        }
      }
    },
    target: "normal",
    type: "Fighting"
}