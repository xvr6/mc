{
    num: 560,
    accuracy: 90,
    basePower: 120,
    category: "Physical",
    name: "Flying Press",
    pp: 10,
    flags: { contact: 1, protect: 1, mirror: 1, gravity: 1, distance: 1, nonsky: 1, metronome: 1 },
    onEffectiveness(typeMod, target, type, move) {
      return typeMod + this.dex.getEffectiveness("Flying", type);
    },
    secondary: {
      chance: 20,
      volatileStatus: "flinch"
    },
    priority: 0,
    target: "any",
    type: "Fighting",
    zMove: { basePower: 180 },
    contestType: "Tough"
}