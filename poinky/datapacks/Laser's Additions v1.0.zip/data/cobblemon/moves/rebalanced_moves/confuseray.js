{
    num: 109,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Confuse Ray",
    pp: 10,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1, light: 1 },
    volatileStatus: "confusion",
    secondary: null,
    target: "normal",
    type: "Ghost",
    zMove: { boost: { spa: 1 } },
    contestType: "Clever"
}