{
    num: 876,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Hydro Steam",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, defrost: 1, metronome: 1 },
    thawsTarget: true,
    secondary: {
      chance: 20,
      status: "brn"
    },
    target: "normal",
    type: "Water"
}