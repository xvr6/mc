{
    num: 294,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Tail Glow",
    pp: 20,
    priority: 0,
    flags: { snatch: 1, metronome: 1, light: 1 },
    boosts: {
      spa: 3
    },
    secondary: null,
    target: "self",
    type: "Bug",
    zMove: { effect: "clearnegativeboost" },
    contestType: "Beautiful"
}