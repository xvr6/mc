{
    num: 125,
    accuracy: 100,
    basePower: 75,
    category: "Physical",
    isNonstandard: "Past",
    name: "Bone Club",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 30,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Ground",
    contestType: "Tough"
}