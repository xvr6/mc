{
    num: 211,
    accuracy: 90,
    basePower: 75,
    category: "Physical",
    name: "Steel Wing",
    pp: 25,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 30,
      self: {
        boosts: {
          def: 1
        }
      }
    },
    target: "normal",
    type: "Steel",
    contestType: "Cool"
}