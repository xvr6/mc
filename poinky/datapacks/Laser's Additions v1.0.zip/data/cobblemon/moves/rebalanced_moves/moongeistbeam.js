{
    num: 714,
    accuracy: 100,
    basePower: 100,
    category: "Special",
    name: "Moongeist Beam",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, light: 1, beam: 1 },
    ignoreAbility: true,
    secondary: null,
    target: "normal",
    type: "Ghost",
    contestType: "Cool"
}