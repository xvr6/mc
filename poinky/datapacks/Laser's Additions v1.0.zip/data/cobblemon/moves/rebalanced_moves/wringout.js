{
    num: 378,
    accuracy: 100,
    basePower: 0,
    basePowerCallback(pokemon, target, move) {
      const hp = target.hp;
      const maxHP = target.maxhp;
      const bp = Math.floor(Math.floor((160 * (100 * Math.floor(hp * 4096 / maxHP)) + 2048 - 1) / 4096) / 100) || 1;
      this.debug("BP for " + hp + "/" + maxHP + " HP: " + bp);
      return bp;
    },
    category: "Special",
    isNonstandard: "Past",
    name: "Wring Out",
    pp: 5,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: null,
    target: "normal",
    type: "Normal",
    zMove: { basePower: 200 },
    maxMove: { basePower: 160 },
    contestType: "Tough"
}