{
    num: 49,
    accuracy: true,
    basePower: 0,
    damage: "level",
    category: "Special",
    isNonstandard: "Past",
    name: "Sonic Boom",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, sound: 1, bypasssub: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.hasAbility(["punkrock","shrieker"])) {
        move.damage = pokemon.level * 1.5;
      }
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cool"
}