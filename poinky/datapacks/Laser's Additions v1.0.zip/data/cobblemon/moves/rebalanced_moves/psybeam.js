{
    num: 60,
    accuracy: 100,
    basePower: 65,
    category: "Special",
    name: "Psybeam",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, beam: 1 },
    secondary: {
      chance: 20,
      volatileStatus: "confusion"
    },
    target: "normal",
    type: "Psychic",
    contestType: "Beautiful"
}