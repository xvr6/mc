{
    num: 13,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    isNonstandard: "Past",
    name: "Razor Wind",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, wind: 1 },
    critRatio: 2,
    secondary: null,
    target: "allAdjacentFoes",
    type: "Normal",
    contestType: "Cool"
}