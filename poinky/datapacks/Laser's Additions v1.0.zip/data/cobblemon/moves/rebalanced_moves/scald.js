{
    num: 503,
    accuracy: 100,
    basePower: 60,
    category: "Special",
    name: "Scald",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, defrost: 1, metronome: 1 },
    thawsTarget: true,
    secondary: {
      chance: 30,
      status: "brn"
    },
    target: "normal",
    type: "Water",
    contestType: "Tough"
}