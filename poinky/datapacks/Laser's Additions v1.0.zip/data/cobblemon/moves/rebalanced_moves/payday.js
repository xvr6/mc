{
    num: 6,
    accuracy: 100,
    basePower: 20,
    category: "Physical",
    name: "Pay Day",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, money: 1 },
    multihit: [2, 5],
    secondary: null,
    target: "normal",
    type: "Normal",
    maxMove: { basePower: 110 },
    contestType: "Clever"
}