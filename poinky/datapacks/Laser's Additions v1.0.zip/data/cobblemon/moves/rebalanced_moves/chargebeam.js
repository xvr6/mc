{
    num: 451,
    accuracy: 100,
    basePower: 40,
    category: "Special",
    name: "Charge Beam",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, beam: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spa: 1
        }
      }
    },
    target: "normal",
    type: "Electric",
    contestType: "Beautiful"
}