{
    num: 459,
    accuracy: 90,
    basePower: 150,
    category: "Special",
    name: "Roar of Time",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, cantusetwice: 1 },
    secondary: null,
    target: "normal",
    type: "Dragon",
    contestType: "Beautiful"
}