{
    num: 490,
    accuracy: 100,
    basePower: 60,
    category: "Physical",
    name: "Low Sweep",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, kick: 1 },
    secondary: {
      chance: 100,
      boosts: {
        spe: -1
      }
    },
    target: "normal",
    type: "Fighting",
    contestType: "Clever"
}