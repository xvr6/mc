{
    num: 671,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Spotlight",
    pp: 15,
    priority: 3,
    flags: { protect: 1, reflectable: 1, allyanim: 1, noassist: 1, failcopycat: 1, light: 1 },
    volatileStatus: "spotlight",
    onTryHit(target) {
      if (this.activePerHalf === 1)
        return false;
    },
    condition: {
      duration: 1,
      onStart(pokemon) {
        this.add("-singleturn", pokemon, "move: Spotlight");
      },
      onFoeRedirectTargetPriority: 2,
      onFoeRedirectTarget(target, source, source2, move) {
        if (this.validTarget(this.effectState.target, source, move.target)) {
          this.debug("Spotlight redirected target of move");
          return this.effectState.target;
        }
      }
    },
    secondary: null,
    target: "adjacentAllyOrSelf",
    type: "Normal",
    zMove: { boost: { spd: 1 } },
    contestType: "Cute"
}