{
    num: 885,
    accuracy: 100,
    basePower: 50,
    category: "Physical",
    name: "Trailblaze",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, kick: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: 1
        }
      }
    },
    target: "normal",
    type: "Grass",
    contestType: "Cool"
}