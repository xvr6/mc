{
    num: 407,
    accuracy: 85,
    basePower: 100,
    category: "Physical",
    name: "Dragon Rush",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 30,
      volatileStatus: "flinch"
    },
    target: "normal",
    type: "Dragon",
    contestType: "Tough"
}