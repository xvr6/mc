{
    num: 41,
    accuracy: 100,
    basePower: 50,
    category: "Physical",
    isNonstandard: "Past",
    name: "Twineedle",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    critRatio: 2,
    multihit: 2,
    secondary: {
      chance: 50,
      status: "psn"
    },
    target: "normal",
    type: "Bug",
    maxMove: { basePower: 150 },
    contestType: "Cool"
}