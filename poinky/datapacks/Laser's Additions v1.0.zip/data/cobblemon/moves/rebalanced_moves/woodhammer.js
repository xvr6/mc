{
    num: 452,
    accuracy: 100,
    basePower: 120,
    category: "Physical",
    name: "Wood Hammer",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, hammer: 1 },
    recoil: [33, 100],
    secondary: null,
    target: "normal",
    type: "Grass",
    contestType: "Tough"
}