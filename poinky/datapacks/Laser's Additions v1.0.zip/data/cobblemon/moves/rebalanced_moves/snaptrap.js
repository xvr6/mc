{
    num: 779,
    accuracy: 100,
    basePower: 35,
    category: "Physical",
    isNonstandard: "Past",
    name: "Snap Trap",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, bite: 1 },
    volatileStatus: "partiallytrapped",
    secondary: null,
    target: "normal",
    type: "Grass"
}