{
    num: 798,
    accuracy: 100,
    basePower: 65,
    category: "Physical",
    name: "Steel Roller",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    basePowerCallback(source, target, move) {
      if (!this.field.isTerrain("")) {
        return move.basePower * 2;
      }
      return move.basePower;
    },
    onAfterHit(target, source) {
      if (source.hp) {
        this.field.clearTerrain();
      }
    },
    onAfterSubDamage(damage, target, source) {
      if (source.hp) {
        this.field.clearTerrain();
      }
    },
    secondary: null,
    target: "normal",
    type: "Steel"
}