{
    num: 890,
    accuracy: 100,
    basePower: 120,
    category: "Special",
    name: "Armor Cannon",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, bullet: 1 },
    self: {
      boosts: {
        def: -1,
        spd: -1
      }
    },
    secondary: null,
    target: "normal",
    type: "Fire"
}