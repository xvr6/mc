{
    num: 15,
    accuracy: true,
    basePower: 60,
    category: "Physical",
    isNonstandard: "Unobtainable",
    name: "Cut",
    pp: 30,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, slicing: 1 },
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cool"
}