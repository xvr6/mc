{
    num: 338,
    accuracy: 90,
    basePower: 150,
    category: "Special",
    name: "Frenzy Plant",
    pp: 5,
    priority: 0,
    flags: { recharge: 1, protect: 1, mirror: 1, nonsky: 1, metronome: 1 },
    self: {
      volatileStatus: "mustrecharge"
    },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    onAfterMove(pokemon) {
      if (pokemon.hp <= pokemon.maxhp / 3 && pokemon.hasAbility("overgrow")) {
        pokemon.removeVolatile("mustrecharge");
        this.add("-activate", pokemon, "move: Frenzy Plant");
      }
    },
    secondary: null,
    target: "normal",
    type: "Grass",
    contestType: "Cool"
}