{
    num: 404,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "X-Scissor",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, slicing: 1 },
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Bug",
    contestType: "Cool"
}