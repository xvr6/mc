{
    num: 817,
    accuracy: 100,
    basePower: 65,
    category: "Physical",
    name: "Wicked Blow",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, punch: 1 },
    willCrit: true,
    secondary: null,
    target: "normal",
    type: "Dark"
}