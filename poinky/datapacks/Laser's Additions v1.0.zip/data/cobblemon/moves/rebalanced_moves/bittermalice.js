{
    num: 841,
    accuracy: 100,
    basePower: 60,
    basePowerCallback(pokemon, target, move) {
      if (target.status || target.hasAbility("comatose"))
        return move.basePower * 2;
      return move.basePower;
    },
    category: "Special",
    name: "Bitter Malice",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 30,
      status: "frz"
    },
    target: "normal",
    type: "Ghost"
}