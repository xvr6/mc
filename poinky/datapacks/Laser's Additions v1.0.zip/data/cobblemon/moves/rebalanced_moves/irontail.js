{
    num: 231,
    accuracy: 85,
    basePower: 100,
    category: "Physical",
    name: "Iron Tail",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 30,
      boosts: {
        def: -1
      }
    },
    target: "normal",
    type: "Steel",
    contestType: "Cool"
}