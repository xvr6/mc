{
    num: 337,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "Dragon Claw",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Dragon",
    contestType: "Cool"
}