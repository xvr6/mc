{
    num: 408,
    accuracy: 100,
    basePower: 80,
    category: "Special",
    name: "Power Gem",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, light: 1, beam: 1 },
    secondary: {
      chance: 30,
      boosts: {
        spa: -1
      }
    },
    target: "normal",
    type: "Rock",
    contestType: "Beautiful"
}