{
    num: 189,
    accuracy: 100,
    basePower: 40,
    category: "Special",
    name: "Mud-Slap",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      boosts: {
        accuracy: -1
      }
    },
    target: "normal",
    type: "Ground",
    contestType: "Cute"
}