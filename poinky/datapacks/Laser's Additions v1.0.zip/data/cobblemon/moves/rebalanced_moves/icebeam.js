{
    num: 58,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Ice Beam",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, beam: 1 },
    secondary: {
      chance: 10,
      status: "frz"
    },
    target: "normal",
    type: "Ice",
    contestType: "Beautiful"
}