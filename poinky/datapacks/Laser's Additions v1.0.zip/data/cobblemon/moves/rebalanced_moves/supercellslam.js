{
    num: 916,
    accuracy: 95,
    basePower: 100,
    category: "Physical",
    name: "Supercell Slam",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    hasCrashDamage: true,
    onMoveFail(target, source, move) {
      if (!source.hasAbility("rockhead")) {
        this.damage(source.baseMaxhp / 2, source, source, this.dex.conditions.get("Supercell Slam"));
      }
    },
    secondary: null,
    target: "normal",
    type: "Electric"
}