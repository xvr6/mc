{
    num: 893,
    accuracy: 100,
    basePower: 160,
    category: "Physical",
    name: "Gigaton Hammer",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, cantusetwice: 1, hammer: 1 },
    secondary: null,
    target: "normal",
    type: "Steel"
}