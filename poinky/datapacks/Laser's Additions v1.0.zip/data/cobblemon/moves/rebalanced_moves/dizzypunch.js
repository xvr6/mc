{
    num: 146,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    isNonstandard: "Past",
    name: "Dizzy Punch",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, punch: 1, metronome: 1 },
    secondary: {
      chance: 30,
      volatileStatus: "confusion"
    },
    target: "normal",
    type: "Normal",
    contestType: "Cute"
}