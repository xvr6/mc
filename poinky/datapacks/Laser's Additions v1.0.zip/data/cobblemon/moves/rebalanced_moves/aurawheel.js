{
    num: 783,
    accuracy: 100,
    basePower: 110,
    category: "Physical",
    name: "Aura Wheel",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, pulse: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: 1
        }
      }
    },
    onModifyType(move, pokemon) {
      if (pokemon.species.name === "Morpeko-Hangry") {
        move.type = "Dark";
      } else {
        move.type = "Electric";
      }
    },
    target: "normal",
    type: "Electric"
}