{
    num: 585,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Moonblast",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1, light: 1 },
    secondary: {
      chance: 30,
      boosts: {
        spa: -1
      }
    },
    target: "normal",
    type: "Fairy",
    contestType: "Beautiful"
}