{
    num: 618,
    accuracy: 85,
    basePower: 110,
    category: "Special",
    name: "Origin Pulse",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, pulse: 1, light: 1, beam: 1 },
    target: "allAdjacentFoes",
    type: "Water",
    contestType: "Beautiful"
}