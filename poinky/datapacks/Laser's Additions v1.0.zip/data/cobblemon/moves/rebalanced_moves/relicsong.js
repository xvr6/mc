{
    num: 547,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Relic Song",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, sound: 1, bypasssub: 1 },
    secondary: {
      chance: 10,
      status: "slp"
    },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    target: "allAdjacentFoes",
    type: "Normal",
    contestType: "Beautiful"
}