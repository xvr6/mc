{
    num: 616,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    isNonstandard: "Past",
    name: "Land's Wrath",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, nonsky: 1, metronome: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Ground",
    zMove: { basePower: 185 },
    contestType: "Beautiful"
}