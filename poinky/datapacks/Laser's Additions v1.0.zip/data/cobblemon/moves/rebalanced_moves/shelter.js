{
    num: 842,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Shelter",
    pp: 10,
    priority: 4,
    flags: { metronome: 1, noassist: 1, failcopycat: 1 },
    stallingMove: true,
    volatileStatus: "shelter",
    onPrepareHit(pokemon) {
      return !!this.queue.willAct() && this.runEvent("StallMove", pokemon);
    },
    onHit(pokemon) {
      pokemon.addVolatile("stall");
    },
    secondary: null,
    target: "self",
    type: "Steel"
}