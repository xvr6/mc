{
    num: 3,
    accuracy: 100,
    basePower: 15,
    category: "Physical",
    isNonstandard: "Past",
    name: "Double Slap",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    multihit: [2, 5],
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cute"
}