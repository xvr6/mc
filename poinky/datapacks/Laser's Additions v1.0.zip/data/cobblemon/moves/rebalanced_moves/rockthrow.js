{
    num: 88,
    accuracy: 100,
    basePower: 50,
    category: "Physical",
    name: "Rock Throw",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, throwing: 1 },
    secondary: null,
    target: "normal",
    type: "Rock",
    contestType: "Tough"
}