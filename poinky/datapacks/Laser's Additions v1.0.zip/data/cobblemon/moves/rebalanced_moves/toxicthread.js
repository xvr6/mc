{
    num: 672,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Toxic Thread",
    pp: 20,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1 },
    status: "tox",
    boosts: {
      spe: -1
    },
    secondary: null,
    target: "normal",
    type: "Poison",
    zMove: { boost: { spe: 1 } },
    contestType: "Tough"
}