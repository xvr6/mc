{
    num: 31,
    accuracy: 100,
    basePower: 15,
    category: "Physical",
    name: "Fury Attack",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    multihit: [2, 5],
    critRatio: 2,
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Cool"
}