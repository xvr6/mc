{
    num: 322,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Cosmic Power",
    pp: 20,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    boosts: {
      def: 1,
      spd: 1
    },
    volatileStatus: "cosmicpower",
    condition: {
      noCopy: true,
      onRestart: () => null
    },
    secondary: null,
    target: "self",
    type: "Psychic",
    zMove: { boost: { spd: 1 } },
    contestType: "Beautiful"
}