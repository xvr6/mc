{
    num: 597,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Aromatic Mist",
    pp: 20,
    priority: 0,
    flags: { bypasssub: 1, metronome: 1 },
    onHitSide(side, source, move) {
      const targets = side.allies();
      if (!targets.length)
        return false;
      let didSomething = false;
      for (const target of targets) {
        if (this.field.isTerrain("mistyterrain") && target.isGrounded()) {
          didSomething = this.boost({ spd: 2 }, target, source, move, false, true) || didSomething;
        } else {
          didSomething = this.boost({ spd: 1 }, target, source, move, false, true) || didSomething;
        }
      }
      return didSomething;
    },
    secondary: null,
    target: "allySide",
    type: "Fairy",
    zMove: { boost: { spd: 2 } },
    contestType: "Beautiful"
}