{
    num: 843,
    accuracy: 100,
    basePower: 30,
    category: "Physical",
    name: "Triple Arrows",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, kick: 1 },
    multihit: 3,
    critRatio: 2,
    secondaries: [
      {
        chance: 15,
        boosts: {
          def: -1
        }
      },
      {
        chance: 10,
        volatileStatus: "flinch"
      }
    ],
    target: "normal",
    type: "Fighting"
}