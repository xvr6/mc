{
    num: 874,
    accuracy: 100,
    basePower: 110,
    category: "Special",
    name: "Make It Rain",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, money: 1 },
    self: {
      boosts: {
        spa: -1
      }
    },
    secondary: null,
    target: "allAdjacentFoes",
    type: "Steel",
    contestType: "Beautiful"
}