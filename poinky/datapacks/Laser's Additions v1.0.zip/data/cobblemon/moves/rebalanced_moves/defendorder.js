{
    num: 455,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Defend Order",
    pp: 10,
    priority: 0,
    flags: { snatch: 1, metronome: 1 },
    onHitSide(side, source, move) {
      const targets = side.allies().filter((target) => target.hasType(["Bug"]) && (!target.volatiles["maxguard"] || this.runEvent("TryHit", target, source, move)));
      if (!targets.length)
        return false;
      let didSomething = false;
      for (const target of targets) {
        if (target.hp <= target.maxhp / 3 && target.hasAbility("swarm")) {
          didSomething = this.boost({ def: 2, spd: 2 }, target, source, move, false, true) || didSomething;
        } else {
          didSomething = this.boost({ def: 1, spd: 1 }, target, source, move, false, true) || didSomething;
        }
      }
      return didSomething;
    },
    secondary: null,
    target: "allySide",
    type: "Bug",
    zMove: { boost: { def: 1 } },
    contestType: "Clever"
  }