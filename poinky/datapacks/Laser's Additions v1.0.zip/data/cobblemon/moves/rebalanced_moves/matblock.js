{
    num: 561,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Mat Block",
    pp: 10,
    priority: 4,
    flags: { snatch: 1, nonsky: 1, noassist: 1, failcopycat: 1 },
    stallingMove: true,
    sideCondition: "matblock",
    onTry(source) {
      if (source.activeMoveActions > 1) {
        this.hint("Mat Block only works on your first turn out.");
        return false;
      }
      return !!this.queue.willAct();
    },
    condition: {
      duration: 1,
      onSideStart(target, source) {
        this.add("-singleturn", source, "Mat Block");
      },
      onTryHitPriority: 3,
      onTryHit(target, source, move) {
        if (!move.flags["protect"]) {
          if (["gmaxoneblow", "gmaxrapidflow"].includes(move.id))
            return;
          if (move.isZ || move.isMax)
            target.getMoveHitData(move).zBrokeProtect = true;
          return;
        }
        if (move && (move.target === "self" || move.category === "Status"))
          return;
        this.add("-activate", target, "move: Mat Block", move.name);
        const lockedmove = source.getVolatile("lockedmove");
        if (lockedmove) {
          if (source.volatiles["lockedmove"].duration === 2) {
            delete source.volatiles["lockedmove"];
          }
        }
        return this.NOT_FAIL;
      }
    },
    secondary: null,
    target: "allySide",
    type: "Fighting",
    zMove: { boost: { def: 1 } },
    contestType: "Cool"
}