{
    num: 411,
    accuracy: 85,
    basePower: 120,
    category: "Special",
    name: "Focus Blast",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: {
      chance: 20,
      boosts: {
        spd: -1
      }
    },
    target: "normal",
    type: "Fighting",
    contestType: "Cool"
}