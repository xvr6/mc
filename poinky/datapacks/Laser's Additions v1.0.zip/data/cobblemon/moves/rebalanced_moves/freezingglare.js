{
    num: 821,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Freezing Glare",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1 },
    secondary: {
      chance: 20,
      status: "frz"
    },
    target: "normal",
    type: "Psychic"
}