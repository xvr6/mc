{
    num: 426,
    accuracy: 90,
    basePower: 65,
    category: "Special",
    isNonstandard: "Past",
    name: "Mud Bomb",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, bullet: 1 },
    secondary: {
      chance: 30,
      boosts: {
        accuracy: -1
      }
    },
    target: "normal",
    type: "Ground",
    contestType: "Cute"
}