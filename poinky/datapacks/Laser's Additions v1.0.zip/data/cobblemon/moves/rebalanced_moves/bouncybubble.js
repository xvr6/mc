{
    num: 733,
    accuracy: 100,
    basePower: 60,
    category: "Special",
    isNonstandard: "LGPE",
    name: "Bouncy Bubble",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, heal: 1 },
    drain: [3, 4],
    secondary: null,
    target: "normal",
    type: "Water",
    contestType: "Clever"
}