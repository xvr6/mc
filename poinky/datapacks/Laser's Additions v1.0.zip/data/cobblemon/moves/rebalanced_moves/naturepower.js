{
    num: 267,
    accuracy: true,
    basePower: 0,
    category: "Status",
    isNonstandard: "Past",
    name: "Nature Power",
    pp: 20,
    priority: 0,
    flags: { failencore: 1, nosleeptalk: 1, noassist: 1, failcopycat: 1, failmimic: 1, failinstruct: 1 },
    onTryHit(target, pokemon) {
      let move = "wildpower";
      if (this.field.isTerrain("electricterrain") && this.field.isWeather("")) {
        move = "electricpower";
      } else if (this.field.isTerrain("grassyterrain") && this.field.isWeather("")) {
        move = "grasspower";
      } else if (this.field.isTerrain("mistyterrain") && this.field.isWeather("")) {
        move = "mistpower";
      } else if (this.field.isTerrain("psychicterrain") && this.field.isWeather("")) {
        move = "psychicpower";
      } else if (this.field.isTerrain("") && this.field.isWeather(["sunnyday", "desolateland"])) {
        move = "sunpower";
      } else if (this.field.isTerrain("") && this.field.isWeather(["raindance", "primordialsea"])) {
        move = "rainpower";
      } else if (this.field.isTerrain("") && this.field.isWeather("sandstorm")) {
        move = "sandpower";
      } else if (this.field.isTerrain("") && this.field.isWeather(["snow", "hail"])) {
        move = "snowpower";
      } else if (this.field.isTerrain("grassyterrain") && this.field.isWeather(["sunnyday", "desolateland"])) {
        move = "springpower";
      } else if (this.field.isTerrain("grassyterrain") && this.field.isWeather(["raindance", "primordialsea"])) {
        move = "swamppower";
      } else if (this.field.isTerrain("grassyterrain") && this.field.isWeather("sandstorm")) {
        move = "frontierpower";
      } else if (this.field.isTerrain("grassyterrain") && this.field.isWeather(["snow", "hail"])) {
        move = "winterpower";
      } else if (this.field.isTerrain("mistyterrain") && this.field.isWeather(["raindance", "primordialsea"])) {
        move = "fogpower";
      } else if (this.field.isTerrain("mistyterrain") && this.field.isWeather(["sunnyday", "desolateland"])) {
        move = "steampower";
      } else if (this.field.isTerrain("mistyterrain") && this.field.isWeather("sandstorm")) {
        move = "crystalpower";
      } else if (this.field.isTerrain("mistyterrain") && this.field.isWeather(["snow", "hail"])) {
        move = "flurrypower";
      } else if (this.field.isTerrain("electricterrain") && this.field.isWeather(["sunnyday", "desolateland"])) {
        move = "solarpower";
      } else if (this.field.isTerrain("electricterrain") && this.field.isWeather(["raindance", "primordialsea"])) {
        move = "stormpower";
      } else if (this.field.isTerrain("electricterrain") && this.field.isWeather("sandstorm")) {
        move = "staticpower";
      } else if (this.field.isTerrain("electricterrain") && this.field.isWeather(["snow", "hail"])) {
        move = "aurorapower";
      } else if (this.field.isTerrain("psychicterrain") && this.field.isWeather(["sunnyday", "desolateland"])) {
        move = "lunarpower";
      } else if (this.field.isTerrain("psychicterrain") && this.field.isWeather(["raindance", "primordialsea"])) {
        move = "brainpower";
      } else if (this.field.isTerrain("psychicterrain") && this.field.isWeather("sandstorm")) {
        move = "relicpower";
      } else if (this.field.isTerrain("psychicterrain") && this.field.isWeather(["snow", "hail"])) {
        move = "timepower";
      }
      this.actions.useMove(move, pokemon, target);
      return null;
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Beautiful"
}