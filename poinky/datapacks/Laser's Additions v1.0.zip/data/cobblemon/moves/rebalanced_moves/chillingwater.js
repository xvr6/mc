{
    num: 886,
    accuracy: 100,
    basePower: 50,
    category: "Special",
    name: "Chilling Water",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1 },
    onBasePower(basePower, source) {
      if (this.field.isWeather(["snow", "hail"])) {
        this.debug("snow buff");
        return this.chainModify(1.5);
      }
    },
    secondary: {
      chance: 100,
      boosts: {
        atk: -1
      }
    },
    target: "normal",
    type: "Water",
    contestType: "Beautiful"
}