{
    num: -3302,
    accuracy: 85,
    basePower: 0,
    category: "Status",
    name: "Chill Out",
    pp: 15,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1, wind: 1 },
    status: "frz",
    secondary: null,
    target: "normal",
    type: "Ice",
    zMove: { boost: { spa: 1 } },
    contestType: "Cool"
}