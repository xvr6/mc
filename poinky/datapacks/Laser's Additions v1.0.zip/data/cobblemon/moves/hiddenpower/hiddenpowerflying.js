{
    num: 237,
    accuracy: 100,
    basePower: 60,
    category: "Special",
    realMove: "Hidden Power",
    isNonstandard: "Past",
    name: "Hidden Power Flying",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1 },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    secondary: null,
    target: "normal",
    type: "Flying",
    contestType: "Clever"
}