{
    num: 237,
    accuracy: 100,
    basePower: 60,
    category: "Special",
    isNonstandard: "Past",
    name: "Hidden Power",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onModifyType(move, pokemon) {
      move.type = pokemon.hpType || "Dark";
    },
    onModifyMove(move, pokemon) {
      if (pokemon.getStat("atk", false, true) > pokemon.getStat("spa", false, true))
        move.category = "Physical";
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Clever"
}