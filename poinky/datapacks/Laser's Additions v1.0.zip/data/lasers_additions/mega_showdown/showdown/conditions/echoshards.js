{
  onSideStart(side) {
    this.add("-sidestart", side, "move: Echo Shards");
  },
  onEntryHazard(pokemon) {
    if (pokemon.hasItem("heavydutyboots"))
      return;
    const typeMod = this.clampIntRange(pokemon.runEffectiveness(this.dex.getActiveMove("echoshards")), -6, 6);
    this.damage(pokemon.maxhp * Math.pow(2, typeMod) / 8);
  },
  flags: {},
  name: "Echo Shards",
  rating: 2,
  num: -1006,
}