{
  duration: 1,
  onStart(target) {
    this.add("-singleturn", target, "Protect");
  },
  onTryHitPriority: 3,
  onTryHit(target, source, move) {
    if (!move.flags["protect"] || move.category === "Status") {
      if (["gmaxoneblow", "gmaxrapidflow"].includes(move.id))
        return;
      if (move.isZ || move.isMax)
        target.getMoveHitData(move).zBrokeProtect = true;
      return;
    }
    if (move.smartTarget) {
      move.smartTarget = false;
    } else {
      this.add("-activate", target, "move: Protect");
    }
    const lockedmove = source.getVolatile("lockedmove");
    if (lockedmove) {
      if (source.volatiles["lockedmove"].duration === 2) {
        delete source.volatiles["lockedmove"];
      }
    }
    if (this.checkMoveMakesContact(move, source, target)) {
      this.boost({ def: 1 }, target, target, this.dex.getActiveMove("Shelter"));
    }
    return this.NOT_FAIL;
  },
  onHit(target, source, move) {
    if (move.isZOrMaxPowered && this.checkMoveMakesContact(move, source, target)) {
      this.boost({ def: 1 }, target, target, this.dex.getActiveMove("Shelter"));
    }
  },
  flags: {},
  name: "Shelter",
  rating: 2,
  num: -1009,
}