{
    name: "frz",
    effectType: "Status",
    onStart(target, source, sourceEffect) {
      if (sourceEffect && sourceEffect.id === "frostorb") {
        this.add("-status", target, "frz", "[from] item: Frost Orb");
      } else if (sourceEffect && sourceEffect.effectType === "Ability") {
        this.add("-status", target, "frz", "[from] ability: " + sourceEffect.name, "[of] " + source);
      } else {
        this.add("-status", target, "frz");
      }
      if (target.species.name === "Shaymin-Sky" && target.baseSpecies.baseSpecies === "Shaymin") {
        target.formeChange("Shaymin", this.effect, true);
      }
    },
    onResidualOrder: 10,
    onResidual(pokemon) {
      this.damage(pokemon.baseMaxhp / 16);
    },
    onAfterMoveSecondary(target, source, move) {
      if (move.thawsTarget) {
        target.cureStatus();
      }
    },
    onModifyMove(move, source, target) {
      if (source.status === 'frz' && !source.hasAbility("resilient") && move.category === 'Special' && move.basePower) {
        this.debug('Freezing halves special move base power');
        move.basePower = Math.floor(move.basePower / 2);
      }
    }
}