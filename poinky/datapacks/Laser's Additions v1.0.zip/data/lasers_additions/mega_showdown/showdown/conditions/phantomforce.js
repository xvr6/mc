{
  duration: 2,
  onInvulnerability(target, source, move) {
    if (["shadowpunch", "hyperspacehole", "hyperspacefury", "phantomforce", "shadowforce"].includes(move.id)) {
      return;
    }
    return false;
  },
  onSourceModifyDamage(damage, source, target, move) {
    if (move.id === "shadowpunch") {
      return this.chainModify(2);
    }
  }
}