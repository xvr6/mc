{
  noCopy: true,
  onStart(target) {
    this.effectState.layers = 1;
    this.effectState.spd = 0;
    this.add("-start", target, "honeygather" + this.effectState.layers);
    const [curSpD] = [target.boosts.spd];
    this.boost({ spd: 1 }, target, target);
    if (curSpD !== target.boosts.spd)
      this.effectState.spd--;
  },
  onRestart(target) {
    if (this.effectState.layers >= 3)
      return false;
    this.effectState.layers++;
    this.add("-start", target, "honeygather" + this.effectState.layers);
    const curSpD = target.boosts.spd;
    this.boost({ spd: 1 }, target, target);
    if (curSpD !== target.boosts.spd)
      this.effectState.spd--;
  },
  onEnd(target) {
    if (this.effectState.spd) {
      const boosts = {};
      if (this.effectState.spd)
        boosts.spd = this.effectState.spd;
      this.boost(boosts, target, target);
    }
    this.add("-end", target, "honeygather");
    if (this.effectState.spd !== this.effectState.layers * -1) {
      this.hint("In Gen 7, honeygather keeps track of how many times it successfully altered each stat individually.");
    }
  },
  flags: {},
  name: "Honey Gather",
  rating: 2,
  num: -1007,
}