{
  name: "cargothrow",
  noCopy: true,
  onTrapPokemon(pokemon) {
    pokemon.tryTrap();
  },
  onStart(target) {
    this.add("-activate", target, "trapped");
  }
}