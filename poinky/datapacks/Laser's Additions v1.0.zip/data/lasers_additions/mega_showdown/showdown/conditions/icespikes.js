{
  onSideStart(side) {
    this.add("-sidestart", side, "move: Ice Spikes");
  },
  onEntryHazard(pokemon) {
    if (pokemon.hasItem("heavydutyboots"))
      return;
    const typeMod = this.clampIntRange(pokemon.runEffectiveness(this.dex.getActiveMove("iceage")), -6, 6);
    this.damage(pokemon.maxhp * Math.pow(2, typeMod) / 8);
  },
  flags: {},
  name: "Ice Spikes",
  rating: 2,
  num: -1004,
}