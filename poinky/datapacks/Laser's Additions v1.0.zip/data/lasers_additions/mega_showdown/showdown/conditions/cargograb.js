{
  name: "cargograb",
  noCopy: true
}