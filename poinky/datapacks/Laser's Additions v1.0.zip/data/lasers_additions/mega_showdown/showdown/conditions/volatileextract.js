{
  onStart(pokemon) {
      this.add('-start', pokemon, 'Volatile Extract');
      this.effectState.counter = 4;
      let success = false;
      let i;
      for (i in pokemon.boosts) {
        if (pokemon.boosts[i] === 0)
          continue;
        pokemon.boosts[i] = -pokemon.boosts[i];
        success = true;
      }
      this.add("-invertboost", pokemon, "[from] move: Volatile Extract");
  },
  onResidualOrder: 28,
  onResidualSubOrder: 2,
  onResidual(pokemon) {
      if (pokemon.activeTurns && this.effectState.counter) {
          this.effectState.counter--;
          if (!this.effectState.counter) {
              this.add('-end', pokemon, 'Volatile Extract');
              let success = false;
              let i;
              for (i in pokemon.boosts) {
                if (pokemon.boosts[i] === 0)
                  continue;
                pokemon.boosts[i] = -pokemon.boosts[i];
                success = true;
              }
              this.add("-invertboost", pokemon, "[from] move: Volatile Extract");
              pokemon.removeVolatile("volatileextract");
              delete this.effectState.counter;
          }
      }
  },
  onChangeBoost(boost, target, source, effect) {
    if (effect && effect.id === "zpower")
      return;
    let i;
    for (i in boost) {
      boost[i] *= -1;
    }
  },
  onEnd(pokemon) {
      if (pokemon.beingCalledBack) return;
      this.add('-end', pokemon, 'Volatile Extract', '[silent]');
  },
  flags: {},
  name: "Volatile Extract",
  rating: 2,
  num: -1003,
}