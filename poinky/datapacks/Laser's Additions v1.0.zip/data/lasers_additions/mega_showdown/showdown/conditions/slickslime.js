{
  noCopy: true,
  onStart(target) {
    this.effectState.layers = 1;
    this.effectState.spd = 0;
    this.add("-start", target, "slickslime" + this.effectState.layers);
    const [curSpD] = [target.boosts.spd];
    this.boost({ spd: 1 }, target, target);
    if (curSpD !== target.boosts.spd)
      this.effectState.spd--;
  },
  onRestart(target) {
    if (this.effectState.layers >= 6)
      return false;
    this.effectState.layers++;
    this.add("-start", target, "slickslime" + this.effectState.layers);
    const curSpD = target.boosts.spd;
    this.boost({ spd: 1 }, target, target);
    if (curSpD !== target.boosts.spd)
      this.effectState.spd--;
  },
  onUpdate(pokemon) {
    if (pokemon.status === "par") {
      this.add("-activate", pokemon, "move: Slick Slime");
      pokemon.cureStatus();
    }
    if (pokemon.volatiles["partiallytrapped"]) {
      this.add("-activate", pokemon, "move: Slick Slime");
      pokemon.removeVolatile("partiallytrapped");
    }
    if (pokemon.volatiles["trapped"]) {
      this.add("-activate", pokemon, "move: Slick Slime");
      pokemon.removeVolatile("trapped");
    }
  },
  onTryAddVolatile(status, target, source, effect) {
    if (["partiallytrapped", "trapped"].includes(status.id)) {
      if (effect.effectType === "Move") {
        const effectHolder = this.effectState.target;
        this.add("-block", target, "move: Slick Slime", "[of] " + effectHolder);
      }
      return null;
    }
  },
  onTryBoost(boost, target, source, effect) {
    if (source && target === source)
      return;
    if (boost.spe && boost.spe < 0) {
      delete boost.spe;
      if (!effect.secondaries) {
        this.add("-fail", target, "unboost", "Speed", "[from] move: Slick Slime", "[of] " + target);
      }
    }
  },
  onDamagingHit(damage, target, source, move) {
    if (["Water"].includes(move.type)) {
      if (this.effectState.layers <= 0)
        return false;
      this.effectState.layers--;
      this.add("-end", target, "slickslime" + this.effectState.layers);
      const curSpD = target.boosts.spd;
      this.boost({ spd: -1 }, target, target);
      if (curSpD !== target.boosts.spd)
        this.effectState.spd--;
    }
  },
  onEnd(target) {
    if (this.effectState.spd) {
      const boosts = {};
      if (this.effectState.spd)
        boosts.spd = this.effectState.spd;
      this.boost(boosts, target, target);
    }
    this.add("-end", target, "slickslime");
    if (this.effectState.spd !== this.effectState.layers * -1) {
      this.hint("In Gen 7, slickslime keeps track of how many times it successfully altered each stat individually.");
    }
  },
  flags: {},
  name: "Slick Slime",
  rating: 2,
  num: -1010,
}