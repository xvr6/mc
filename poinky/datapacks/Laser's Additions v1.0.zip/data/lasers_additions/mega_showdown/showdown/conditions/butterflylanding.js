{
	onResidualOrder: 25,
	onStart(target) {
		if (target.terastallized) {
			if (target.hasType('Flying')) {
				this.add('-hint', "If a Terastallized Pokemon uses Butterfly Landing, it remains Flying-type.");
			}
		}
		this.add('-start', target, 'move: Butterfly Landing');
	},
  onModifyMove(move, pokemon) {
    if (move.secondaries && move.id !== "secretpower") {
      this.debug("increasing secondary chance");
      for (const secondary of move.secondaries) {
        if (pokemon.hasAbility("serenegrace") && secondary.volatileStatus === "flinch")
          continue;
        if (secondary.chance)
          secondary.chance *= 2;
      }
      if (move.self?.chance)
        move.self.chance *= 2;
    }
  },
  onModifyAtkPriority: 5,
  onModifyAtk(atk, attacker, defender, move) {
    if (move.type === "Flying" && !attacker.hasType('Flying')) {
      this.debug("Butterfly Landing STAB");
      return this.chainModify(1.5);
    }
  },
  onModifySpAPriority: 5,
  onModifySpA(atk, attacker, defender, move) {
    if (move.type === "Flying" && !attacker.hasType('Flying')) {
      this.debug("Butterfly Landing STAB");
      return this.chainModify(1.5);
    }
  },
	onTypePriority: -1,
	onType(types, pokemon) {
		if (!pokemon.terastallized) {
		  this.effectState.typeWas = types;
		  return types.filter(type => type !== 'Flying');
    }
	},
  flags: {},
  name: "Butterfly Landing",
  rating: 2,
  num: -1002,
}