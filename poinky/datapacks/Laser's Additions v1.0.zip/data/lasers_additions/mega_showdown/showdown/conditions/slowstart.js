{
  onStart(pokemon) {
      this.add('-start', pokemon, 'ability: Slow Start');
      this.effectState.counter = 3;
  },
  onResidualOrder: 28,
  onResidualSubOrder: 2,
  onResidual(pokemon) {
      if (pokemon.activeTurns && this.effectState.counter) {
          this.effectState.counter--;
          if (!this.effectState.counter) {
              this.add('-end', pokemon, 'Slow Start');
              this.boost({ spe: 1 });
              delete this.effectState.counter;
          }
      }
  },
  onModifyAtkPriority: 5,
  onModifyAtk(atk, pokemon) {
      if (this.effectState.counter) {
          return this.chainModify(0.5);
      }
  },
  onModifySpe(spe, pokemon) {
      if (this.effectState.counter) {
          return this.chainModify(0.5);
      }
  },
  onEnd(pokemon) {
      if (pokemon.beingCalledBack) return;
      this.add('-end', pokemon, 'Slow Start', '[silent]');
  },
  flags: {},
  name: "Slow Start",
  rating: -1,
  num: 112,
}