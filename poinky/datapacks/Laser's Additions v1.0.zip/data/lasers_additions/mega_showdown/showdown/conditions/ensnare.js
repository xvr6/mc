{
  duration: 1,
  onBeforeSwitchOut(pokemon) {
    this.debug("Ensnare start");
    let alreadyAdded = false;
    pokemon.removeVolatile("destinybond");
    for (const source of this.effectState.sources) {
      if (!source.isAdjacent(pokemon) || !this.queue.cancelMove(source) || !source.hp)
        continue;
      if (!alreadyAdded) {
        this.add("-activate", pokemon, "move: Ensnare");
        alreadyAdded = true;
      }
      if (source.canMegaEvo || source.canUltraBurst) {
        for (const [actionIndex, action] of this.queue.entries()) {
          if (action.pokemon === source && action.choice === "megaEvo") {
            this.actions.runMegaEvo(source);
            this.queue.list.splice(actionIndex, 1);
            break;
          }
        }
      }
      this.actions.runMove("ensnare", source, source.getLocOf(pokemon));
    }
  },
  flags: {},
  name: "Ensnare",
  rating: 2,
  num: -1008,
}