{
    name: "DesolateLand",
    effectType: "Weather",
    duration: 0,
    onTryMovePriority: 1,
    onTryMove(attacker, defender, move) {
      if (move.type === "Water" && move.category !== "Status") {
        this.debug("Desolate Land water suppress");
        this.add("-fail", attacker, move, "[from] Desolate Land");
        this.attrLastMove("[still]");
        return null;
      }
    },
    onWeatherModifyDamage(damage, attacker, defender, move) {
      if (move.id === "scorchingsands" && !attacker.hasItem("utilityumbrella")) {
        this.debug("Sunny Day Scorching Sands boost");
        return this.chainModify(1.5);
      }
      if (defender.hasItem("utilityumbrella"))
        return;
      if (move.type === "Fire") {
        this.debug("Sunny Day fire boost");
        return this.chainModify(1.5);
      }
    },
    onFieldStart(field, source, effect) {
      this.add("-weather", "DesolateLand", "[from] ability: " + effect.name, "[of] " + source);
    },
    onImmunity(type, pokemon) {
      if (pokemon.hasItem("utilityumbrella"))
        return;
      if (type === "frz")
        return false;
    },
    onFieldResidualOrder: 1,
    onFieldResidual() {
      this.add("-weather", "DesolateLand", "[upkeep]");
      this.eachEvent("Weather");
    },
    onFieldEnd() {
      this.add("-weather", "none");
    }
}