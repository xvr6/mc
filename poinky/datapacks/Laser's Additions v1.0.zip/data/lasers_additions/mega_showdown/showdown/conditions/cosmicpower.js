{
  noCopy: true,
  onRestart: () => null,
  flags: {},
  name: "Cosmic Power",
  rating: 2,
  num: -1001,
}