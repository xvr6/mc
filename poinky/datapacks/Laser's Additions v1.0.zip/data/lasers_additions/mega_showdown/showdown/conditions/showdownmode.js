{
  onStart(pokemon) {
      this.add('-start', pokemon, 'Showdown Mode');
      this.effectState.counter = 4;
      this.boost({ atk: 1, spa: 1, spe: 1 });
  },
  onResidualOrder: 28,
  onResidualSubOrder: 2,
  onResidual(pokemon) {
      if (pokemon.activeTurns && this.effectState.counter) {
          this.effectState.counter--;
          if (!this.effectState.counter) {
              this.add('-end', pokemon, 'Showdown Mode');
              this.boost({ atk: -1, spa: -1, spe: -1, def: -1, spd: -1 });
              delete this.effectState.counter;
          }
      }
  },
  onEnd(pokemon) {
      if (pokemon.beingCalledBack) return;
      this.add('-end', pokemon, 'Showdown Mode', '[silent]');
  },
  flags: {},
  name: "Showdown Mode",
  rating: 2,
  num: -1000,
}