{
  duration: 5,
  onSideStart(targetSide) {
    this.add("-sidestart", targetSide, "Mirror Shield");
  },
  onSideResidualOrder: 26,
  onSideResidualSubOrder: 7,
  onSideEnd(targetSide) {
    this.add("-sideend", targetSide, "Mirror Shield");
  },
  onTryHitPriority: 4,
  onTryHit(target, source, move) {
    if (move?.target !== "allAdjacent" && move.target !== "allAdjacentFoes") {
      return;
    }
    if (move.isZ || move.isMax) {
      if (["gmaxoneblow", "gmaxrapidflow"].includes(move.id))
        return;
      target.getMoveHitData(move).zBrokeProtect = true;
      return;
    }
    this.add("-activate", target, "move: Iron Age");
    const lockedmove = source.getVolatile("lockedmove");
    if (lockedmove) {
      if (source.volatiles["lockedmove"].duration === 2) {
        delete source.volatiles["lockedmove"];
      }
    }
    return this.NOT_FAIL;
  },
  flags: {},
  name: "Mirror Shield",
  rating: 2,
  num: -1005,
}