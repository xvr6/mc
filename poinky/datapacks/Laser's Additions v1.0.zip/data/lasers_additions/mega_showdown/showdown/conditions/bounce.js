{
  duration: 2,
  onInvulnerability(target, source, move) {
    if (["gust", "twister", "skyuppercut", "dragonsfist", "thunder", "hurricane", "smackdown", "hammerdown", "thousandarrows"].includes(move.id)) {
      return;
    }
    return false;
  },
  onSourceModifyDamage(damage, source, target, move) {
    if (move.id === "gust" || move.id === "twister") {
      return this.chainModify(2);
    }
  }
}