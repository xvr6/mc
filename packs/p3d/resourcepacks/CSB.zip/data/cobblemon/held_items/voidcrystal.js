({
    name: "Void Crystal",
    onBasePowerPriority: 15,
    onBasePower(basePower, user, target, move) {
      if (user.baseSpecies.num === 400 && (move.type === "Psychic" || move.type === "Ghost")) {
        return this.chainModify([4915, 4096]);
      }
    },
    onTakeItem(item, pokemon, source) {
      if (source?.baseSpecies.num === 400 || pokemon.baseSpecies.num === 400) {
        return false;
      }
      return true;
    },
    num: 73692,
})