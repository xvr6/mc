({
    onTryHit(target, source, move) {
      if (target !== source && move.type === "Bug") {
        if (!this.heal(target.baseMaxhp / 4)) {
          this.add("-immune", target, "[from] ability: Insectivore");
        }
        return null;
      }
    },
    flags: { breakable: 1 },
    name: "Insectivore",
    rating: 3.5
  })