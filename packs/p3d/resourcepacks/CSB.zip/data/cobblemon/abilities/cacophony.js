({
    onBasePowerPriority: 7,
    onBasePower(basePower, attacker, defender, move) {
      if (move.flags["sound"]) {
        this.debug("Cacophony boost");
        return this.chainModify([5325, 4096]);
      }
    },
    onSourceModifyDamage(damage, source, target, move) {
      if (move.flags["sound"]) {
        this.debug("Cacophony weaken");
        return this.chainModify(0.5);
      }
    },
    flags: { breakable: 1 },
    name: "Cacophony",
    rating: 3.5
  })