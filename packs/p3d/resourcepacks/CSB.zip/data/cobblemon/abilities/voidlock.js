({
    onStart(source) {
      this.field.setTerrain("gravity");
    },
    flags: { failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1 },
    name: "Void Lock",
    rating: 3
  })