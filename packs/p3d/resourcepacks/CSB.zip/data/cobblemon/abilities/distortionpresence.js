({
    onEffectiveness(typeMod, target, type, move) {
      if (move && target.getMoveHitData(move).typeMod > 0) {
      this.add("-activate", target, "ability: Distortion Presence");
      return -1;
      }
    },
    onEffectiveness(typeMod, target, type, move) {
      if (move && target.getMoveHitData(move).typeMod == -1) {
      this.add("-activate", target, "ability: Distortion Presence");
      return 1;
      }
    },
    onEffectiveness(typeMod, target, type, move) {
      if (move && target.getMoveHitData(move).typeMod > 0) {
      this.add("-activate", target, "ability: Distortion Presence");
      return -1;
      }
    },
    flags: { failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1, breakable: 1 },
    name: "Distortion Presence",
    rating: 3.5
  })