({
    onSourceDamagingHit(damage, target, source, move) {
      if (["raindance", "primordialsea"].includes(pokemon.effectiveWeather())) {
      if (!move.type == "Electric")
        return;
      if (target.hasAbility("shielddust") || target.hasItem("covertcloak"))
        return;
      if (this.randomChance(5, 10)) {
        target.trySetStatus("par", source);
      }
    }
    },
    flags: {},
    name: "Short Circuit",
    rating: 4.5
  })