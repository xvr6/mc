({
    onStart(source) {
      this.field.setTerrain("trickroom");
    },
    onModifyPriority(priority, pokemon, target, move) {
      if (this.field.isTerrain("trickroom"))
        return priority + 1;
    },
    flags: { failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1 },
    name: "Temporal Presence",
    rating: 4
  })