({
    onPrepareHit(source, target, move) {
      if (move.type == "Water" || move.type == "Dragon" ||move.category === "Status" || move.multihit || move.flags["noparentalbond"] || move.flags["charge"] || move.flags["futuremove"] || move.spreadHit || move.isZ || move.isMax)
        return;
      move.spreadHit = 2;
      move.spreadHitType = "spacialpresence";
    },
    onSourceModifySecondaries(secondaries, target, source, move) {
      if (move.spreadHitType === "spacialpresence" && move.id === "secretpower" && move.hit < 2) {
        return secondaries.filter((effect) => effect.volatileStatus === "flinch");
      }
    },
    flags: { failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1 },
    name: "Spacial Presence",
    rating: 4.5
  })