({
    onTryHit(target, source, move) {
      if (target !== source && move.flags["pulse"]) {
        this.add("-immune", target, "[from] ability: Faulty Receiver");
        return null;
      }
    },
    onAllyTryHitSide(target, source, move) {
      if (move.flags["pulse"]) {
        this.add("-immune", this.effectState.target, "[from] ability: Faulty Receiver");
      }
    },
    flags: { breakable: 1 },
    name: "Faulty Receiver",
    rating: 2
  })