({
    onTryHealPriority: 19,
    onTryHeal(damage, target, source, effect) {
      if (source === target) {
        this.debug("Overvitality boost");
        return this.chainModify([5120, 4096]);
      }
    },
    onBasePowerPriority: 8,
    onBasePower(basePower, attacker, defender, move) {
      if (move.drain) {
        this.debug("Overvitality boost");
        return this.chainModify(1.5);
      }
    },
    name: "Overvitality",
    rating: 3.5,
})