({    
    onAnyRedirectTarget(target, source, source2, move) {
    if (source.isAlly(this.effectState.target)) 
      return;
    if (move.flags["pledgecombo"]) 
      return;
    const redirectTarget = ["randomNormal", "adjacentFoe"].includes(move.target) ? "normal" : move.target;
    if (this.validTarget(this.effectState.target, source, redirectTarget)) {
        if (move.smartTarget) 
          move.smartTarget = false;
        if (this.effectState.target !== target) {
            this.add("-activate", this.effectState.target, "ability: Warding Compass");
        }
        return this.effectState.target;
      }
    },
    flags: { breakable: 1 },
    name: "Warding Compass",
    rating: 3
  })