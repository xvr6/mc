({  num: 640022,
    accuracy: 100,
    basePower: 70,
    category: "Special",
    name: "Rusting Water",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    onEffectiveness(typeMod, target, type) {
      if (type === "Steel")
        return 1;
    },
    secondary: null,
    target: "normal",
    type: "Water",
    contestType: "Beautiful"
  })