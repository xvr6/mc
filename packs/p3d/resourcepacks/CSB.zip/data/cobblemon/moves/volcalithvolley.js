({  num: 640033,
    accuracy: 75,
    basePower: 100,
    category: "Special",
    name: "Volcalith Volley",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    self: {
      onHit(source) {
        for (const side of source.side.foeSidesWithConditions()) {
          side.addSideCondition("gmaxvolcalith");
        }
      }
    },
    condition: {
      duration: 4,
      onSideStart(targetSide) {
        this.add("-sidestart", targetSide, "G-Max Volcalith");
      },
      onResidualOrder: 5,
      onResidualSubOrder: 1,
      onResidual(target) {
        if (!target.hasType("Rock"))
          this.damage(target.baseMaxhp / 6, target);
      },
      onSideResidualOrder: 26,
      onSideResidualSubOrder: 11,
      onSideEnd(targetSide) {
        this.add("-sideend", targetSide, "G-Max Volcalith");
      }
    },
    secondary: null,
    target: "normal",
    type: "Rock",
    contestType: "Tough"
  })