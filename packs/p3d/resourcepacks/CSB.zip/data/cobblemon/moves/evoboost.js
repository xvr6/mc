({  num: 640012,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Evoboost",
    pp: 5,
    priority: 0,
    flags: { snatch: 1 },
    volatileStatus: "evoboost",
    onTry(source) {
      if (source.hp <= source.maxhp * 33 / 100 || source.maxhp === 1)
        return false;
      if (source.volatiles["evoboost"])
        return false;
    },
    onTryHit(pokemon, target, move) {
      if (!this.boost(move.boosts))
        return null;
      delete move.boosts;
    },
    onHit(pokemon) {
      this.directDamage(pokemon.maxhp * 33 / 100);
    },
    boosts: {
      atk: 1,
      def: 1,
      spa: 1,
      spd: 1,
      spe: 1
    },
    secondary: null,
    target: "self",
    type: "Normal"
  })