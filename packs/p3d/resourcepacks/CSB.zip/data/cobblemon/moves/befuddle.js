({  num: 640003,
    accuracy: 100,
    basePower: 75,
    category: "Special",
    name: "Befuddle",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, distance: 1, metronome: 1 },
    secondary: {
      chance: 30,
      volatileStatus: "confusion"
    },
    target: "normal",
    type: "Bug",
    contestType: "Beautiful"
  })