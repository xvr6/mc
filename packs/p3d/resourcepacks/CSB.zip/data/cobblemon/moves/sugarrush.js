({  num: 640030,
    accuracy: 100,
    basePower: 50,
    category: "Physical",
    name: "Sugar Rush",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: 1
        }
      }
    },
    target: "normal",
    type: "Fairy",
    contestType: "Cool"
  })