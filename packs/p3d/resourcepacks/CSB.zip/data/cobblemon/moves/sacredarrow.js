
    ({num: 640023,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Sacred Arrow",
    pp: 10,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      volatileStatus: "healblock"
    },
    target: "normal",
    type: "Fire"
  })