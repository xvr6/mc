({  num: 640002,
    accuracy: 100,
    basePower: 85,
    category: "Special",
    name: "Banshee Scream",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, sound: 1, bypasssub: 1, metronome: 1 },
    secondary: {
      chance: 20,
      boosts: {
        atk: -1
      }
    },
    target: "allAdjacentFoes",
    type: "Ghost",
    contestType: "Cool"
  })