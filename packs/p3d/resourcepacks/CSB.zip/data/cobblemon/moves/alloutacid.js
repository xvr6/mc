({  num: 640001,
    accuracy: 100,
    basePower: 130,
    category: "Special",
    isNonstandard: "Unobtainable",
    name: "All-Out Acid",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, defrost: 1, metronome: 1 },
    onTryMove(pokemon, target, move) {
      if (pokemon.hasType("Poison"))
        return;
      this.add("-fail", pokemon, "move: All-Out Acid");
      this.attrLastMove("[still]");
      return null;
    },
    self: {
      onHit(pokemon) {
        pokemon.setType(pokemon.getTypes(true).map((type) => type === "Poison" ? "???" : type));
        this.add("-start", pokemon, "typechange", pokemon.getTypes().join("/"), "[from] move: All-Out Acid");
      }
    },
    secondary: null,
    target: "normal",
    type: "Poison",
    contestType: "Clever"
  })