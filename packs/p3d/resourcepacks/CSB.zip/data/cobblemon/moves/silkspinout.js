({  num: 640024,
    accuracy: 90,
    basePower: 65,
    category: "Physical",
    name: "Silk Spin-Out",
    pp: 15,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1},
    onAfterHit(target, source, move) {
      if (!move.hasSheerForce && source.hp) {
        for (const side of source.side.foeSidesWithConditions()) {
          side.addSideCondition("stickyweb");
        }
      }
    },
    onAfterSubDamage(damage, target, source, move) {
      if (!move.hasSheerForce && source.hp) {
        for (const side of source.side.foeSidesWithConditions()) {
          side.addSideCondition("stickyweb");
        }
      }
    },
    secondary: {},
    target: "normal",
    type: "Bug",
    contestType: "Clever"
  })