({  num: 640036,
    accuracy: 100,
    basePower: 20,
    category: "Physical",
    name: "Slipstream",
    pp: 50,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: 1
        }
      }
    },
    target: "normal",
    type: "Flying",
    contestType: "Clever"
  })