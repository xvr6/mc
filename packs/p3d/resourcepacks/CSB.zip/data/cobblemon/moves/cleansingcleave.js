({  num: 640008,
    accuracy: 100,
    basePower: 90,
    category: "Physical",
    name: "Cleansing Cleave",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1, slicing: 1 },
    secondary: {
      dustproof: true,
      chance: 100,
      volatileStatus: "cleansingcleave"
    },    basePowerCallback(pokemon, target, move) {
      if (target.status || target.hasAbility("comatose")) {
        this.debug("BP doubled from status condition");
        return move.basePower * 2;
      }
      return move.basePower;
    },
    onAfterMove(source, target, move) {
      for (const pokemon of this.getAllActive()) {
        if (pokemon !== source && pokemon.removeVolatile("cleansingcleave") && pokemon.status && !source.fainted) {
          pokemon.cureStatus();
        }
      }
    },
    target: "normal",
    type: "Grass",
    contestType: "Tough"
  })