({  num: 640034,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Warm Welcome",
    pp: 20,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    onTry(source) {
      if (source.activeMoveActions > 1) {
        this.hint("Warm Welcome only works on your first turn out.");
        return false;
      }
    },
    boosts: {
      spd: -1,
      def: -1
    },
    secondary: null,
    target: "normal",
    type: "Normal",
    contestType: "Clever"
  })