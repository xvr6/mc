({  num: 640018,
    accuracy: 100,
    basePower: 90,
    category: "Special",
    name: "Mochi Mania",
    pp: 15,
    priority: 0,
    flags: { protect: 1, mirror: 1, allyanim: 1, metronome: 1, bullet: 1 },
    onTryHit(target, source, move) {
      if (source.isAlly(target)) {
        move.basePower = 0;
        move.infiltrates = true;
      }
    },
    onTryMove(source, target, move) {
      if (source.isAlly(target) && source.volatiles["healblock"]) {
        this.attrLastMove("[still]");
        this.add("cant", source, "move: Heal Block", move);
        return false;
      }
    },
    onHit(target, source, move) {
      if (source.isAlly(target)) {
        if (!this.heal(Math.floor(target.baseMaxhp * 0.5))) {
          if (target.volatiles["healblock"] && target.hp !== target.maxhp) {
            this.attrLastMove("[still]");
            this.add("cant", source, "move: Heal Block", move);
          } else {
            this.add("-immune", target);
          }
          return this.NOT_FAIL;
        }
      }
    },
    secondary: null,
    target: "normal",
    type: "Ground",
    contestType: "Cute"
  })