({  num: 640005,
    accuracy: 85,
    basePower: 0,
    category: "Status",
    name: "Chill-O-Wisp",
    pp: 15,
    priority: 0,
    flags: { protect: 1, reflectable: 1, mirror: 1, metronome: 1 },
    boosts: {
      spa: -1,
      spe: -1
    },
    secondary: null,
    target: "normal",
    type: "Ice",
    zMove: { boost: { spa: 1 } },
    contestType: "Beautiful"
  })