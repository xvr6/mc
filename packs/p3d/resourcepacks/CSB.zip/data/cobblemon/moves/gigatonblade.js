({  num: 640014,
    accuracy: 100,
    basePower: 100,
    category: "Physical",
    name: "Gigaton Blade",
    pp: 5,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1, cantusetwice: 1, slicing: 1 },
    secondary: null,
    critRatio: 2,
    target: "normal",
    type: "Steel",
    contestType: "Tough"
  })