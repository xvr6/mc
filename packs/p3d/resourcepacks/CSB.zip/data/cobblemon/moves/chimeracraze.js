({  num: 640006,
    accuracy: 100,
    basePower: 80,
    category: "Physical",
    name: "Chimera Craze",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    onTryHit(pokemon) {
      pokemon.side.removeSideCondition("reflect");
      pokemon.side.removeSideCondition("lightscreen");
      pokemon.side.removeSideCondition("auroraveil");
    },
    drain: [1, 2],
    secondary: null,
    target: "normal",
    type: "Fairy",
    contestType: "Cool"
  })