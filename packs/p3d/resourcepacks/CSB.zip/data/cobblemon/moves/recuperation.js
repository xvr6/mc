({
    num: 640038,
    accuracy: true,
    basePower: 0,
    category: "Status",
    name: "Recuperation",
    pp: 5,
    priority: 0,
    flags: { snatch: 1, heal: 1, metronome: 1 },
    heal: [1, 2],
    secondary: {
      chance: 100,
      self: {
        boosts: {
          spe: -1
        }
      }
    },
    target: "self",
    type: "Electric",
    zMove: { effect: "clearnegativeboost" },
    contestType: "Clever"
  })