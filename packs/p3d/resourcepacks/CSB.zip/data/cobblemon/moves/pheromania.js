({  num: 640020,
    accuracy: 100,
    basePower: 0,
    category: "Status",
    name: "Pheromania",
    pp: 20,
    priority: 0,
    flags: { protect: 1, mirror: 1, metronome: 1 },
    boosts: {
      evasion: -2
    },
    onHit(target, source, move) {
      return target.addVolatile("trapped", source, move, "trapper");
    },
    condition: {
      onStart(pokemon, source, effect) {
        if (!(pokemon.gender === "M" && source.gender === "F") && !(pokemon.gender === "F" && source.gender === "M")) {
          this.debug("incompatible gender");
          return false;
        }
    }
  },
    secondary: null,
    target: "normal",
    type: "Bug",
    contestType: "Tough"
  })