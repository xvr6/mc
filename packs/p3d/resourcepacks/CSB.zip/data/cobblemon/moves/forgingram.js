({  num: 640013,
    accuracy: 90,
    basePower: 100,
    category: "Physical",
    name: "Forging Ram",
    pp: 10,
    priority: 0,
    flags: { contact: 1, protect: 1, mirror: 1, metronome: 1 },
    secondaries: [
      {
        chance: 30,
        boosts: {
          def: -1
        }
      },
      {
        chance: 30,
        status: "brn"
      }
    ],
    target: "normal",
    type: "Steel",
    contestType: "Tough"
  })