# MODIFIED BY WEAVER - REMOVAL OF STARTER INFO





Hi, Kenji here!
Thank you for getting my addon 'Cobblemon Stellar Blue'! I hope that you'll enjoy my Fakemon creations ^^

Some notes in advance:

- As you might notice all off the starters have been replaced by the Lumoran ones. No need to panic, there is an easy fix
  to this. Simply turn on customStarters in the cobblemon config file and you should have all of the starters again PLUS
  the Lumoran ones! The old method to get the custom starter screen is outdated.
- Infastella, Stellotl, Stellumbra and Neuveon will obtain different obtainment methods in the future when legendary and deviant Pokémon
  are officially introduced.
- There will constantly be balance changes to my Fakemon, as me and my balancing council test our Pokémon frequently.
  Every balance change was done for a reason. There is no need to modify my Fakemon's species on your own. 
  (It's not allowed to do that and distribute it anyways...)
- Megas will not get modeled until Mega Pokémon are an official feature of Cobblemon. I do not play to add them via a sidemod or anything of the likes
  and would like you to not do the same either. Please be patient.

- Please for the love of Arceus do not ask me when the next update drops. I literally JUST dropped this one...

- PLEASE DON'T use my addon on any big public server without my permission. With big server I mean such as ones with ranks, crates 
  and the likes. If it's one for your friends or a small community like an SMP, I don't see why you wouldn't be allowed to use it.

List of all Fakemon currently available:
- Tigriff, Griffern & Griffaera (Starter)
- Emberam, Aurnaram & Midauries (Starter)
- Equelpi, Equiross & Equirin (Starter)
- Liwyrm, Kaevern & Wyrmend
- Quantom & Phantasmau
- Lamaggot & Mortifly
- Fropple & Amfrosia
- Fluffle
- Bronzombro
- Maroyal
- Dusbun & Jackalune (REMODEL)
- Lumini, Luminova & Luminarity
- Bootoo (NEW)
- Woofloo & Dubfool
- Lumoran Fomantis & Lurantis
- Neuveon
- Infastella, Stellotl & Stellumbra

Models and final data coming soon:
- Chirpity, Chirpeck & Emperoost
- Froxicate
- [Awakened Forme] Stellumbra

List of all rideable Pokémon:
- Griffaera
- Midauries
- Equirin
- Wyrmend
- Fluffle
- Dubfool
- [Awakened Forme] Stellotl

Regular Pokémon:
- Azurill, Marill & Azumarill (REMODEL)

Stellar Forms:
- Magikarp & Gyarados
- Vivillon

Cosmetic Variants:
- Griffaera (Flower), Item: Poppy, Dandelion, Blue Orchid, Azure Bluet, Orange Tulip
- Midauries (Netherite), Item: Netherite Chestplate
- Bronzombro (Gilded Chests)

Item Interactions:
- Tigriff, brush
- Griffern, brush
- Griffaera, brush, bone meal
- Midauries, raw gold, iron or copper
- Equirin, brush
- Jackalune, brush
- Bootoo, brush
- Stellotl, hold Netherite Star with >180 friendship

New Moves: (Disclaimer: None of these moves are applied to any Pokémon. They are only available via the /teach command and are just there for fun)
- Quick Jolt
- Rusting Water
- Chroma Crash
- Sugar Rush
- All-Out Acid
- Terminal Velocity
- Effective Explosion
- Starfire Breath
- Chill O' Wisp
- Pheromania
- Warm Welcome
- Befuddle
- Monkey Business
- Dust Devil
- Sacred Arrow
- Slipstream (NEW)
- Dynamo Dash (NEW)
- Recuperation (NEW)

New Held Items:
- Star Crystal (Boosts Stellotl's Dragon and Fairy moves by 20%. Allows it to awaken its true form.)

New Marks/Ribbons:
- Lumora Champion Ribbon
- Stellar Ribbon
- Greedy Mark

New Wallpapers:
- Hyperstellar
- Fluffle
- Snugglebugs
- Everything is fine

New Signature Moves:
- Chimera Craze (Griffaera)
- Forging Ram (Midauries)
- Miracle Mist (Equirin)
- Disastrous Aura (Wyrmend)
- Cataclysm (Phantasmau)
- Mochi Mania (Jackalune)
- Cleansing Cleave (Amfrosia)
- Hyperstellar Burst (Stellotl)
- Hyperstellar Strike (Stellumbra)
- Supernova (Lumini line and other cosmic Pokémon)
- Singularity (Luminarity)
- Star Thunder (Alolan Raichu, Luxray) (ONLY VIA /TEACH)
- Silk-Spin Out (spiders) (ONLY VIA /TEACH)
- Starburst (Minior)
- Evoboost (Neuveon)
- Crystal Constrict (Cryogonal) (ONLY VIA /TEACH)
- Volcalith Volley (volcanic Pokémon) (ONLY VIA /TEACH)
- Gigaton Blade [COMING SOON]
- Banshee Scream (Bootoo)
- Spare Change (Bronzombro)
- Wind Surfing (Mantine) (ONLY VIA /TEACH)

New Abilities:
- Celestial Body (Stellotl Awakened)
- Void Lock (Stellumbra Awakened)
- Warding Compass (Infastella)
- Enchanted Armor (Amfrosia)
- True Colors (Neuveon)
- Faulty Receiver
- Wildfire
- Cacophony
- Snow Call
- Absolute Zero
- Temporal Presence
- Spacial Presence
- Distortion Presence
- Insectivore
- Heart Breaker
- Short Circuit
- Overvitality



------------
Credits:
- Every model and animation, Fakemon design (if not mentioned specifically) - by me (Kenji_64)
- Cover Art - by me (Kenji_64)
- PC wallpaper pixelart - by me (Kenji_64)
- Lumini, Luminova and Luminarity - by ScarletSpectral
- Most of the cries - by Pandam
- Move & Ability Data - by BlueZulfish
- Spawn Files - by Jerżyk
- Ride Data Balancing Help - by Jerżyk
- Balancing Council - BlueZulfish, Jerżyk, TealiBean and me (Kenji_64)
- L. Fomantis and L. Lurantis models - by 46ratsinamaidcostume
- Woofloo and Dubfool cry sounds - by Saucecoie
- Woofloo and Dubfool models - by Jerżyk
- Neuveon cry sound - BlueZulfish

Without further ado, let's jump in and get some new friends from the Lumora Region! Happy hunting!
- Kenji, lead of the Stellar Blue Team